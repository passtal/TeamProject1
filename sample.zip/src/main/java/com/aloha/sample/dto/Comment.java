package com.aloha.sample.dto;

import java.util.Date;

import lombok.Data;

/**
 * 댓글 DTO
 * - 테이블: club_comments
 */
@Data
public class Comment {
    private int no;                  // PK
    private int boardNo;             // FK (club_boards.no)
    private int writerNo;            // FK (users.no)
    private String content;          // 댓글 내용
    private int likeCount;           // 좋아요 수
    private Date createdAt;          // 등록일
    private Date updatedAt;          // 수정일

    // 연관 데이터
    private User writer;             // 작성자 정보
    private boolean isLiked;         // 좋아요 여부 (현재 사용자)
}
