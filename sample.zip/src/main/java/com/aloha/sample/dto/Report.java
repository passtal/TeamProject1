package com.aloha.sample.dto;

import java.util.Date;

import lombok.Data;

/**
 * 모임 멤버 신고 내역 DTO
 * - 테이블: club_member_reports
 */
@Data
public class Report {
    private int no;              // PK
    private int clubNo;          // FK (clubs.no) - 신고가 발생한 모임
    private int reporterNo;      // FK (users.no) - 신고한 회원
    private int targetNo;        // FK (users.no) - 신고당한 회원
    private String reason;       // 신고 사유
    private Date createdAt;      // 신고 일시

    // 연관 데이터
    private User reporter;       // 신고자 정보
    private User target;         // 신고 대상 정보
    private Club club;           // 모임 정보
}
