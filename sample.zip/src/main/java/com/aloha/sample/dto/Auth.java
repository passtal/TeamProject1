package com.aloha.sample.dto;

import java.util.Date;

import lombok.Data;

/**
 * 권한 DTO
 * - 테이블: user_auth
 */
@Data
public class Auth {
    private int no;              // PK
    private int userNo;          // FK (users.no)
    private String auth;         // 권한 (ROLE_USER, ROLE_HOST, ROLE_ADMIN)
    private Date createdAt;      // 등록일
    private Date updatedAt;      // 수정일
}
