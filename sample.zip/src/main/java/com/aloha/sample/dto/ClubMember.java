package com.aloha.sample.dto;

import java.util.Date;

import lombok.Data;

/**
 * 모임 참가자 DTO
 * - 테이블: club_members
 */
@Data
public class ClubMember {
    private int no;              // PK
    private int clubNo;          // FK (clubs.no)
    private int userNo;          // FK (users.no)
    private String status;       // 참가상태 (PENDING, APPROVED, REJECTED)
    private Date joinedAt;       // 가입일

    // 연관 데이터
    private User user;           // 회원 정보
    private Club club;           // 모임 정보
}
