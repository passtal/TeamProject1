package com.aloha.sample.dto;

import java.util.Date;

import lombok.Data;

/**
 * 자동 로그인 DTO
 * - 테이블: persistence_logins
 */
@Data
public class PersistentLogin {
    private int no;              // PK
    private String id;           // UUID
    private String userId;       // 회원 아이디
    private String token;        // 인증 토큰
    private Date expiryDate;     // 만료시간
    private Date createdAt;      // 등록일
    private Date updatedAt;      // 수정일
}
