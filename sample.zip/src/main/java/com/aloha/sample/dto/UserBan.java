package com.aloha.sample.dto;

import java.util.Date;

import lombok.Data;

/**
 * 회원 차단 이력 DTO
 * - 테이블: user_bans
 */
@Data
public class UserBan {
    private int no;                  // PK
    private int userNo;              // FK (users.no) - 차단된 유저
    private String reason;           // 차단 사유
    private int reportCountAtBan;    // 차단 시점 신고 누적 횟수
    private String banType;          // 차단 유형 (TEMPORARY, PERMANENT)
    private Date banEndDate;         // 차단 해제 예정일 (영구 차단 시 NULL)
    private String isActive;         // 현재 차단 상태 (Y/N)
    private Date createdAt;          // 차단 일시
    private Date updatedAt;          // 수정일

    // 연관 데이터
    private User user;               // 차단된 회원 정보
}
