package com.aloha.sample.dto;

import java.util.Date;
import java.util.List;

import lombok.Data;

/**
 * 모임 DTO
 * - 테이블: clubs
 */
@Data
public class Club {
    private int no;                  // PK
    private int hostNo;              // FK (users.no) - 모임장
    private int categoryNo;          // FK (categories.no)
    private Integer subCategoryNo;   // FK (sub_categories.no) - nullable
    private String title;            // 모임명
    private String description;      // 모임 설명
    private String thumbnailImg;     // 썸네일 이미지
    private int maxMembers;          // 모집 인원수
    private int currentMembers;      // 현재 참가자 수
    private Date deadline;           // 마감일
    private String location;         // 모임 장소
    private Date clubDate;           // 모임 일시
    private String status;           // 모임상태 (RECRUITING, CLOSED, COMPLETED)
    private int viewCount;           // 조회수
    private int likeCount;           // 좋아요 수
    private Date createdAt;          // 등록일
    private Date updatedAt;          // 수정일

    // 연관 데이터
    private User host;               // 모임장 정보
    private Category category;       // 대분류 카테고리
    private SubCategory subCategory; // 소분류 카테고리
    private List<ClubMember> memberList;  // 멤버 목록
    private boolean isLiked;         // 좋아요 여부 (현재 사용자)
}
