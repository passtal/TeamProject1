package com.aloha.sample.dto;

import java.util.Date;
import java.util.List;

import lombok.Data;

/**
 * 회원 DTO
 * - 테이블: users
 */
@Data
public class User {
    private int no;                  // PK
    private String id;               // UUID (UK)
    private String userId;           // 아이디(이메일)
    private String password;         // 비밀번호(BCrypt)
    private String username;         // 닉네임
    private String profileImg;       // 프로필 이미지
    private int age;                 // 나이
    private String gender;           // 성별
    private String address;          // 주거지
    private int reportCount;         // 신고 누적 횟수
    private String isBanned;         // 차단 여부 (Y/N)
    private Date bannedAt;           // 차단 일시
    private Date createdAt;          // 등록일
    private Date updatedAt;          // 수정일

    // 연관 데이터
    private List<Auth> authList;     // 권한 목록
}
