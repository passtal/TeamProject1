package com.aloha.sample.dto;

import java.util.Date;

import lombok.Data;

/**
 * 게시글 좋아요 DTO
 * - 테이블: club_board_likes
 */
@Data
public class BoardLike {
    private int no;              // PK
    private int boardNo;         // FK (club_boards.no)
    private int userNo;          // FK (users.no)
    private Date createdAt;      // 등록일
}
