package com.aloha.sample.dto;

import java.util.Date;
import java.util.List;

import lombok.Data;

/**
 * 게시글 DTO
 * - 테이블: club_boards
 */
@Data
public class Board {
    private int no;                  // PK
    private int clubNo;              // FK (clubs.no)
    private int writerNo;            // FK (users.no)
    private String title;            // 제목
    private String content;          // 내용
    private int viewCount;           // 조회수
    private int likeCount;           // 좋아요 수
    private int commentCount;        // 댓글 수
    private String isNotice;         // 공지 여부 (Y/N)
    private Date createdAt;          // 등록일
    private Date updatedAt;          // 수정일

    // 연관 데이터
    private User writer;             // 작성자 정보
    private Club club;               // 모임 정보
    private List<BoardImage> imageList;  // 이미지 목록
    private List<Comment> commentList;   // 댓글 목록
    private boolean isLiked;         // 좋아요 여부 (현재 사용자)
}
