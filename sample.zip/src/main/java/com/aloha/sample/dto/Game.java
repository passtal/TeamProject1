package com.aloha.sample.dto;

import java.util.Date;

import lombok.Data;

/**
 * 랜덤 게임 DTO
 * - 테이블: random_games
 */
@Data
public class Game {
    private int no;              // PK
    private int clubNo;          // FK (clubs.no)
    private String gameType;     // 게임 종류 (ROULETTE, LADDER, RANDOM_PICK)
    private String title;        // 게임 제목
    private String options;      // 게임 옵션들 (JSON)
    private String result;       // 결과
    private int createdBy;       // FK (users.no)
    private Date createdAt;      // 등록일

    // 연관 데이터
    private User creator;        // 생성자 정보
    private Club club;           // 모임 정보
}
