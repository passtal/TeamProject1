package com.aloha.sample.dto;

import java.util.Date;
import java.util.List;

import lombok.Data;

/**
 * 대분류 카테고리 DTO
 * - 테이블: categories
 */
@Data
public class Category {
    private int no;                  // PK
    private String name;             // 카테고리명
    private String description;      // 카테고리 설명
    private String icon;             // 카테고리 아이콘
    private int seq;                 // 정렬순서
    private Date createdAt;          // 등록일
    private Date updatedAt;          // 수정일

    // 연관 데이터
    private List<SubCategory> subCategoryList;  // 소분류 목록
}
