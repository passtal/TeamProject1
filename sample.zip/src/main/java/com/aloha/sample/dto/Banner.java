package com.aloha.sample.dto;

import java.util.Date;

import lombok.Data;

/**
 * 배너 DTO
 * - 테이블: banners
 */
@Data
public class Banner {
    private int no;              // PK
    private String title;        // 배너 제목
    private String imageUrl;     // 배너 이미지
    private String linkUrl;      // 클릭 시 이동 URL
    private String position;     // 배너 위치 (MAIN, SIDE, POPUP)
    private String isActive;     // 활성화 여부 (Y/N)
    private Date startDate;      // 노출 시작일
    private Date endDate;        // 노출 종료일
    private int seq;             // 정렬순서
    private int clickCount;      // 클릭수
    private Date createdAt;      // 등록일
    private Date updatedAt;      // 수정일
}
