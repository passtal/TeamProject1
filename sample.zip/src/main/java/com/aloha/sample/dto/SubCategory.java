package com.aloha.sample.dto;

import java.util.Date;

import lombok.Data;

/**
 * 소분류 카테고리 DTO
 * - 테이블: sub_categories
 */
@Data
public class SubCategory {
    private int no;              // PK
    private int categoryNo;      // FK (categories.no)
    private String name;         // 소분류명
    private int seq;             // 정렬순서
    private Date createdAt;      // 등록일
    private Date updatedAt;      // 수정일

    // 연관 데이터
    private Category category;   // 대분류 카테고리
}
