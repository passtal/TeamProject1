package com.aloha.sample.dto;

import lombok.Data;

/**
 * 게시글 이미지 DTO
 * - 테이블: club_board_images
 */
@Data
public class BoardImage {
    private int no;              // PK
    private int boardNo;         // FK (club_boards.no)
    private String imageUrl;     // 이미지 URL
    private int seq;             // 순서
}
