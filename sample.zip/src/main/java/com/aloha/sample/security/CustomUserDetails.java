package com.aloha.sample.security;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.aloha.sample.dto.User;

/**
 * Spring Security UserDetails 구현체
 */
public class CustomUserDetails implements UserDetails {

    private static final long serialVersionUID = 1L;
    
    private User user;
    private List<String> authorities;

    public CustomUserDetails(User user, List<String> authorities) {
        this.user = user;
        this.authorities = authorities;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        return authorities.stream()
                .map(SimpleGrantedAuthority::new)
                .collect(Collectors.toList());
    }

    @Override
    public String getPassword() {
        return user.getPassword();
    }

    @Override
    public String getUsername() {
        return user.getUserId();
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        // 차단 여부 확인
        return !"Y".equals(user.getIsBanned());
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
    
    /**
     * User 객체 반환
     */
    public User getUser() {
        return user;
    }
    
    /**
     * 회원 번호 반환
     */
    public int getNo() {
        return user.getNo();
    }
    
    /**
     * 사용자 이름 반환
     */
    public String getUserName() {
        return user.getUsername();
    }
    
    /**
     * 프로필 이미지 반환
     */
    public String getProfileImg() {
        return user.getProfileImg();
    }
}
