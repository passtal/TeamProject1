package com.aloha.sample.security;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.aloha.sample.dao.AuthMapper;
import com.aloha.sample.dao.UserMapper;
import com.aloha.sample.dto.Auth;
import com.aloha.sample.dto.User;

/**
 * Spring Security UserDetailsService 구현체
 */
@Service
public class CustomUserDetailsService implements UserDetailsService {

    @Autowired
    private UserMapper userMapper;
    
    @Autowired
    private AuthMapper authMapper;

    @Override
    public UserDetails loadUserByUsername(String userId) throws UsernameNotFoundException {
        User user = userMapper.selectByUserId(userId);
        
        if (user == null) {
            throw new UsernameNotFoundException("사용자를 찾을 수 없습니다: " + userId);
        }
        
        // 권한 목록 조회
        List<Auth> authList = authMapper.listByUserNo(user.getNo());
        List<String> authorities = authList.stream()
                .map(Auth::getAuth)
                .collect(Collectors.toList());
        
        return new CustomUserDetails(user, authorities);
    }
}
