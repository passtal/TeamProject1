package com.aloha.sample.controller;

import java.security.Principal;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.aloha.sample.dto.Auth;
import com.aloha.sample.dto.User;
import com.aloha.sample.service.UserService;

/**
 * 사용자 컨트롤러
 */
@Controller
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    /**
     * 로그인 페이지
     */
    @GetMapping("/login")
    public String login(@RequestParam(value = "error", required = false) String error,
                        @RequestParam(value = "logout", required = false) String logout,
                        Model model) {
        if (error != null) {
            model.addAttribute("error", "아이디 또는 비밀번호가 일치하지 않습니다.");
        }
        if (logout != null) {
            model.addAttribute("message", "로그아웃되었습니다.");
        }
        return "user/login";
    }
    
    /**
     * 회원가입 페이지
     */
    @GetMapping("/join")
    public String join(Model model) {
        model.addAttribute("user", new User());
        return "user/join";
    }
    
    /**
     * 회원가입 처리
     */
    @PostMapping("/join")
    public String joinPro(User user, RedirectAttributes rttr) {
        // UUID 생성
        user.setId(UUID.randomUUID().toString());
        // 비밀번호 암호화
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        
        try {
            int result = userService.insert(user);
            
            if (result > 0) {
                // 기본 권한 부여
                Auth auth = new Auth();
                auth.setUserNo(user.getNo());
                auth.setAuth("ROLE_USER");
                userService.insertAuth(auth);
                
                rttr.addFlashAttribute("message", "회원가입이 완료되었습니다.");
                return "redirect:/user/login";
            }
        } catch (Exception e) {
            rttr.addFlashAttribute("error", "회원가입 중 오류가 발생했습니다.");
        }
        
        return "redirect:/user/join";
    }
    
    /**
     * 아이디 중복 체크 (AJAX)
     */
    @GetMapping("/check-id")
    public @org.springframework.web.bind.annotation.ResponseBody boolean checkId(@RequestParam String userId) {
        return userService.selectByUserId(userId) == null;
    }
    
    /**
     * 마이페이지
     */
    @GetMapping("/mypage")
    public String mypage(Principal principal, Model model) {
        User user = userService.selectByUserId(principal.getName());
        model.addAttribute("user", user);
        return "user/mypage";
    }
    
    /**
     * 정보 수정 페이지
     */
    @GetMapping("/edit")
    public String edit(Principal principal, Model model) {
        User user = userService.selectByUserId(principal.getName());
        model.addAttribute("user", user);
        return "user/edit";
    }
    
    /**
     * 정보 수정 처리
     */
    @PostMapping("/edit")
    public String editPro(User user, Principal principal, RedirectAttributes rttr) {
        User currentUser = userService.selectByUserId(principal.getName());
        user.setNo(currentUser.getNo());
        
        // 비밀번호 변경 시 암호화
        if (user.getPassword() != null && !user.getPassword().isEmpty()) {
            user.setPassword(passwordEncoder.encode(user.getPassword()));
        } else {
            user.setPassword(currentUser.getPassword());
        }
        
        int result = userService.update(user);
        if (result > 0) {
            rttr.addFlashAttribute("message", "정보가 수정되었습니다.");
        } else {
            rttr.addFlashAttribute("error", "수정에 실패했습니다.");
        }
        
        return "redirect:/user/mypage";
    }
    
    /**
     * 회원 탈퇴 페이지
     */
    @GetMapping("/delete")
    public String delete() {
        return "user/delete";
    }
    
    /**
     * 회원 탈퇴 처리
     */
    @PostMapping("/delete")
    public String deletePro(@RequestParam String password, 
                           Principal principal, 
                           RedirectAttributes rttr,
                           Authentication authentication) {
        User user = userService.selectByUserId(principal.getName());
        
        if (passwordEncoder.matches(password, user.getPassword())) {
            userService.delete(user.getNo());
            return "redirect:/user/logout";
        } else {
            rttr.addFlashAttribute("error", "비밀번호가 일치하지 않습니다.");
            return "redirect:/user/delete";
        }
    }
}
