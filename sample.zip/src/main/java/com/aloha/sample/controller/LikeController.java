package com.aloha.sample.controller;

import java.security.Principal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aloha.sample.dto.User;
import com.aloha.sample.service.LikeService;
import com.aloha.sample.service.UserService;

/**
 * 좋아요 REST 컨트롤러
 */
@RestController
@RequestMapping("/api/like")
public class LikeController {

    @Autowired
    private LikeService likeService;
    
    @Autowired
    private UserService userService;

    /**
     * 모임 좋아요 토글
     */
    @PostMapping("/club/{clubNo}")
    public ResponseEntity<Map<String, Object>> toggleClubLike(
            @PathVariable("clubNo") int clubNo,
            Principal principal) {
        
        Map<String, Object> response = new HashMap<>();
        
        if (principal == null) {
            response.put("success", false);
            response.put("message", "로그인이 필요합니다.");
            return ResponseEntity.status(401).body(response);
        }
        
        User user = userService.selectByUserId(principal.getName());
        boolean liked = likeService.toggleClubLike(clubNo, user.getNo());
        
        response.put("success", true);
        response.put("liked", liked);
        response.put("message", liked ? "좋아요를 눌렀습니다." : "좋아요를 취소했습니다.");
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 게시글 좋아요 토글
     */
    @PostMapping("/board/{boardNo}")
    public ResponseEntity<Map<String, Object>> toggleBoardLike(
            @PathVariable("boardNo") int boardNo,
            Principal principal) {
        
        Map<String, Object> response = new HashMap<>();
        
        if (principal == null) {
            response.put("success", false);
            response.put("message", "로그인이 필요합니다.");
            return ResponseEntity.status(401).body(response);
        }
        
        User user = userService.selectByUserId(principal.getName());
        boolean liked = likeService.toggleBoardLike(boardNo, user.getNo());
        
        response.put("success", true);
        response.put("liked", liked);
        response.put("message", liked ? "좋아요를 눌렀습니다." : "좋아요를 취소했습니다.");
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 댓글 좋아요 토글
     */
    @PostMapping("/comment/{commentNo}")
    public ResponseEntity<Map<String, Object>> toggleCommentLike(
            @PathVariable("commentNo") int commentNo,
            Principal principal) {
        
        Map<String, Object> response = new HashMap<>();
        
        if (principal == null) {
            response.put("success", false);
            response.put("message", "로그인이 필요합니다.");
            return ResponseEntity.status(401).body(response);
        }
        
        User user = userService.selectByUserId(principal.getName());
        boolean liked = likeService.toggleCommentLike(commentNo, user.getNo());
        
        response.put("success", true);
        response.put("liked", liked);
        response.put("message", liked ? "좋아요를 눌렀습니다." : "좋아요를 취소했습니다.");
        
        return ResponseEntity.ok(response);
    }
}
