package com.aloha.sample.controller;

import java.security.Principal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aloha.sample.dto.Report;
import com.aloha.sample.dto.User;
import com.aloha.sample.service.ReportService;
import com.aloha.sample.service.UserService;

/**
 * 신고 REST 컨트롤러
 */
@RestController
@RequestMapping("/api/report")
public class ReportController {

    @Autowired
    private ReportService reportService;
    
    @Autowired
    private UserService userService;

    /**
     * 신고 접수
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> report(@RequestBody Report report,
                                                      Principal principal) {
        Map<String, Object> response = new HashMap<>();
        
        if (principal == null) {
            response.put("success", false);
            response.put("message", "로그인이 필요합니다.");
            return ResponseEntity.status(401).body(response);
        }
        
        User user = userService.selectByUserId(principal.getName());
        report.setReporterNo(user.getNo());
        
        // 자기 자신 신고 방지
        if (report.getTargetNo() == user.getNo()) {
            response.put("success", false);
            response.put("message", "자기 자신을 신고할 수 없습니다.");
            return ResponseEntity.badRequest().body(response);
        }
        
        // 중복 신고 확인
        if (reportService.isDuplicate(report.getClubNo(), user.getNo(), report.getTargetNo())) {
            response.put("success", false);
            response.put("message", "이미 해당 회원을 신고했습니다.");
            return ResponseEntity.badRequest().body(response);
        }
        
        int result = reportService.insert(report);
        
        if (result > 0) {
            response.put("success", true);
            response.put("message", "신고가 접수되었습니다.");
        } else {
            response.put("success", false);
            response.put("message", "신고 접수에 실패했습니다.");
        }
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 신고 취소
     */
    @PostMapping("/{no}/cancel")
    public ResponseEntity<Map<String, Object>> cancel(@PathVariable("no") int no,
                                                      Principal principal) {
        Map<String, Object> response = new HashMap<>();
        
        if (principal == null) {
            response.put("success", false);
            response.put("message", "로그인이 필요합니다.");
            return ResponseEntity.status(401).body(response);
        }
        
        Report report = reportService.selectByNo(no);
        User user = userService.selectByUserId(principal.getName());
        
        if (report == null) {
            response.put("success", false);
            response.put("message", "신고 내역을 찾을 수 없습니다.");
            return ResponseEntity.notFound().build();
        }
        
        // 신고자만 취소 가능
        if (report.getReporterNo() != user.getNo()) {
            response.put("success", false);
            response.put("message", "취소 권한이 없습니다.");
            return ResponseEntity.status(403).body(response);
        }
        
        int result = reportService.delete(no);
        
        if (result > 0) {
            response.put("success", true);
            response.put("message", "신고가 취소되었습니다.");
        } else {
            response.put("success", false);
            response.put("message", "신고 취소에 실패했습니다.");
        }
        
        return ResponseEntity.ok(response);
    }
}
