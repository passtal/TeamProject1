package com.aloha.sample.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.aloha.sample.dto.Category;
import com.aloha.sample.dto.Club;
import com.aloha.sample.dto.ClubMember;
import com.aloha.sample.dto.SubCategory;
import com.aloha.sample.dto.User;
import com.aloha.sample.service.CategoryService;
import com.aloha.sample.service.ClubService;
import com.aloha.sample.service.UserService;

/**
 * 모임 컨트롤러
 */
@Controller
@RequestMapping("/club")
public class ClubController {

    @Autowired
    private ClubService clubService;
    
    @Autowired
    private CategoryService categoryService;
    
    @Autowired
    private UserService userService;

    /**
     * 모임 목록 페이지
     */
    @GetMapping("/list")
    public String list(@RequestParam(value = "category", required = false) Integer categoryNo,
                       @RequestParam(value = "sub", required = false) Integer subCategoryNo,
                       @RequestParam(value = "keyword", required = false) String keyword,
                       @RequestParam(value = "page", defaultValue = "1") int page,
                       Model model) {
        
        List<Club> clubs;
        
        if (keyword != null && !keyword.isEmpty()) {
            clubs = clubService.search(keyword);
        } else if (subCategoryNo != null) {
            clubs = clubService.listBySubCategory(subCategoryNo);
        } else if (categoryNo != null) {
            clubs = clubService.listByCategory(categoryNo);
        } else {
            clubs = clubService.list();
        }
        
        List<Category> categories = categoryService.list();
        
        model.addAttribute("clubs", clubs);
        model.addAttribute("categories", categories);
        model.addAttribute("categoryNo", categoryNo);
        model.addAttribute("subCategoryNo", subCategoryNo);
        model.addAttribute("keyword", keyword);
        
        return "club/list";
    }
    
    /**
     * 모임 상세 페이지
     */
    @GetMapping("/{no}")
    public String detail(@PathVariable("no") int no, 
                        Principal principal, 
                        Model model) {
        // 조회수 증가
        clubService.incrementViewCount(no);
        
        Club club = clubService.selectByNo(no);
        List<ClubMember> members = clubService.listMembers(no);
        
        model.addAttribute("club", club);
        model.addAttribute("members", members);
        
        // 로그인 사용자의 가입 상태 확인
        if (principal != null) {
            User user = userService.selectByUserId(principal.getName());
            ClubMember myMembership = clubService.selectMember(no, user.getNo());
            model.addAttribute("myMembership", myMembership);
            model.addAttribute("isHost", club.getHostNo() == user.getNo());
        }
        
        return "club/detail";
    }
    
    /**
     * 모임 생성 페이지
     */
    @GetMapping("/create")
    public String create(Model model) {
        List<Category> categories = categoryService.list();
        model.addAttribute("categories", categories);
        model.addAttribute("club", new Club());
        return "club/create";
    }
    
    /**
     * 서브카테고리 조회 (AJAX)
     */
    @GetMapping("/subcategories/{categoryNo}")
    public @org.springframework.web.bind.annotation.ResponseBody List<SubCategory> getSubCategories(
            @PathVariable("categoryNo") int categoryNo) {
        return categoryService.listSubByCategory(categoryNo);
    }
    
    /**
     * 모임 생성 처리
     */
    @PostMapping("/create")
    public String createPro(Club club, Principal principal, RedirectAttributes rttr) {
        User user = userService.selectByUserId(principal.getName());
        club.setHostNo(user.getNo());
        club.setStatus("RECRUITING");
        club.setCurrentMembers(1);
        
        int result = clubService.insert(club);
        
        if (result > 0) {
            // 호스트를 멤버로 추가
            ClubMember member = new ClubMember();
            member.setClubNo(club.getNo());
            member.setUserNo(user.getNo());
            member.setStatus("APPROVED");
            clubService.insertMember(member);
            
            rttr.addFlashAttribute("message", "모임이 생성되었습니다.");
            return "redirect:/club/" + club.getNo();
        }
        
        rttr.addFlashAttribute("error", "모임 생성에 실패했습니다.");
        return "redirect:/club/create";
    }
    
    /**
     * 모임 수정 페이지
     */
    @GetMapping("/{no}/edit")
    public String edit(@PathVariable("no") int no, Principal principal, Model model) {
        Club club = clubService.selectByNo(no);
        User user = userService.selectByUserId(principal.getName());
        
        // 호스트만 수정 가능
        if (club.getHostNo() != user.getNo()) {
            return "redirect:/club/" + no;
        }
        
        List<Category> categories = categoryService.list();
        List<SubCategory> subCategories = categoryService.listSubByCategory(club.getCategoryNo());
        
        model.addAttribute("club", club);
        model.addAttribute("categories", categories);
        model.addAttribute("subCategories", subCategories);
        
        return "club/edit";
    }
    
    /**
     * 모임 수정 처리
     */
    @PostMapping("/{no}/edit")
    public String editPro(@PathVariable("no") int no, Club club, 
                         Principal principal, RedirectAttributes rttr) {
        Club existingClub = clubService.selectByNo(no);
        User user = userService.selectByUserId(principal.getName());
        
        if (existingClub.getHostNo() != user.getNo()) {
            return "redirect:/club/" + no;
        }
        
        club.setNo(no);
        int result = clubService.update(club);
        
        if (result > 0) {
            rttr.addFlashAttribute("message", "모임이 수정되었습니다.");
        } else {
            rttr.addFlashAttribute("error", "수정에 실패했습니다.");
        }
        
        return "redirect:/club/" + no;
    }
    
    /**
     * 모임 삭제
     */
    @PostMapping("/{no}/delete")
    public String delete(@PathVariable("no") int no, Principal principal, RedirectAttributes rttr) {
        Club club = clubService.selectByNo(no);
        User user = userService.selectByUserId(principal.getName());
        
        if (club.getHostNo() != user.getNo()) {
            return "redirect:/club/" + no;
        }
        
        clubService.delete(no);
        rttr.addFlashAttribute("message", "모임이 삭제되었습니다.");
        return "redirect:/club/list";
    }
    
    /**
     * 모임 가입 신청
     */
    @PostMapping("/{no}/join")
    public String join(@PathVariable("no") int no, Principal principal, RedirectAttributes rttr) {
        User user = userService.selectByUserId(principal.getName());
        
        // 이미 가입/신청 여부 확인
        ClubMember existing = clubService.selectMember(no, user.getNo());
        if (existing != null) {
            rttr.addFlashAttribute("error", "이미 가입 신청을 했습니다.");
            return "redirect:/club/" + no;
        }
        
        ClubMember member = new ClubMember();
        member.setClubNo(no);
        member.setUserNo(user.getNo());
        member.setStatus("PENDING");
        
        clubService.insertMember(member);
        rttr.addFlashAttribute("message", "가입 신청이 완료되었습니다.");
        
        return "redirect:/club/" + no;
    }
    
    /**
     * 가입 승인/거절 (호스트용)
     */
    @PostMapping("/{no}/member/{memberNo}/approve")
    public String approveMember(@PathVariable("no") int no,
                                @PathVariable("memberNo") int memberNo,
                                @RequestParam("status") String status,
                                Principal principal,
                                RedirectAttributes rttr) {
        Club club = clubService.selectByNo(no);
        User user = userService.selectByUserId(principal.getName());
        
        if (club.getHostNo() != user.getNo()) {
            return "redirect:/club/" + no;
        }
        
        clubService.updateMemberStatus(memberNo, status);
        
        if ("APPROVED".equals(status)) {
            clubService.incrementMemberCount(no);
            rttr.addFlashAttribute("message", "가입을 승인했습니다.");
        } else {
            rttr.addFlashAttribute("message", "가입을 거절했습니다.");
        }
        
        return "redirect:/club/" + no;
    }
    
    /**
     * 모임 탈퇴
     */
    @PostMapping("/{no}/leave")
    public String leave(@PathVariable("no") int no, Principal principal, RedirectAttributes rttr) {
        User user = userService.selectByUserId(principal.getName());
        Club club = clubService.selectByNo(no);
        
        // 호스트는 탈퇴 불가
        if (club.getHostNo() == user.getNo()) {
            rttr.addFlashAttribute("error", "호스트는 탈퇴할 수 없습니다.");
            return "redirect:/club/" + no;
        }
        
        ClubMember member = clubService.selectMember(no, user.getNo());
        if (member != null && "APPROVED".equals(member.getStatus())) {
            clubService.decrementMemberCount(no);
        }
        clubService.deleteMember(no, user.getNo());
        
        rttr.addFlashAttribute("message", "모임에서 탈퇴했습니다.");
        return "redirect:/club/list";
    }
}
