package com.aloha.sample.controller;

import java.security.Principal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aloha.sample.dto.Comment;
import com.aloha.sample.dto.User;
import com.aloha.sample.service.CommentService;
import com.aloha.sample.service.UserService;

/**
 * 댓글 REST 컨트롤러
 */
@RestController
@RequestMapping("/api/comment")
public class CommentController {

    @Autowired
    private CommentService commentService;
    
    @Autowired
    private UserService userService;

    /**
     * 게시글별 댓글 목록
     */
    @GetMapping("/board/{boardNo}")
    public ResponseEntity<List<Comment>> listByBoard(@PathVariable("boardNo") int boardNo) {
        List<Comment> comments = commentService.listByBoard(boardNo);
        return ResponseEntity.ok(comments);
    }
    
    /**
     * 댓글 단건 조회
     */
    @GetMapping("/{no}")
    public ResponseEntity<Comment> selectByNo(@PathVariable("no") int no) {
        Comment comment = commentService.selectByNo(no);
        if (comment == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(comment);
    }
    
    /**
     * 댓글 작성
     */
    @PostMapping
    public ResponseEntity<Map<String, Object>> insert(@RequestBody Comment comment, 
                                                      Principal principal) {
        Map<String, Object> response = new HashMap<>();
        
        if (principal == null) {
            response.put("success", false);
            response.put("message", "로그인이 필요합니다.");
            return ResponseEntity.status(401).body(response);
        }
        
        User user = userService.selectByUserId(principal.getName());
        comment.setWriterNo(user.getNo());
        
        int result = commentService.insert(comment);
        
        if (result > 0) {
            response.put("success", true);
            response.put("message", "댓글이 작성되었습니다.");
            response.put("commentNo", comment.getNo());
        } else {
            response.put("success", false);
            response.put("message", "댓글 작성에 실패했습니다.");
        }
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 댓글 수정
     */
    @PutMapping("/{no}")
    public ResponseEntity<Map<String, Object>> update(@PathVariable("no") int no,
                                                      @RequestBody Comment comment,
                                                      Principal principal) {
        Map<String, Object> response = new HashMap<>();
        
        if (principal == null) {
            response.put("success", false);
            response.put("message", "로그인이 필요합니다.");
            return ResponseEntity.status(401).body(response);
        }
        
        Comment existing = commentService.selectByNo(no);
        User user = userService.selectByUserId(principal.getName());
        
        if (existing == null) {
            response.put("success", false);
            response.put("message", "댓글을 찾을 수 없습니다.");
            return ResponseEntity.notFound().build();
        }
        
        // 작성자만 수정 가능
        if (existing.getWriterNo() != user.getNo()) {
            response.put("success", false);
            response.put("message", "수정 권한이 없습니다.");
            return ResponseEntity.status(403).body(response);
        }
        
        comment.setNo(no);
        int result = commentService.update(comment);
        
        if (result > 0) {
            response.put("success", true);
            response.put("message", "댓글이 수정되었습니다.");
        } else {
            response.put("success", false);
            response.put("message", "댓글 수정에 실패했습니다.");
        }
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * 댓글 삭제
     */
    @DeleteMapping("/{no}")
    public ResponseEntity<Map<String, Object>> delete(@PathVariable("no") int no,
                                                      Principal principal) {
        Map<String, Object> response = new HashMap<>();
        
        if (principal == null) {
            response.put("success", false);
            response.put("message", "로그인이 필요합니다.");
            return ResponseEntity.status(401).body(response);
        }
        
        Comment existing = commentService.selectByNo(no);
        User user = userService.selectByUserId(principal.getName());
        
        if (existing == null) {
            response.put("success", false);
            response.put("message", "댓글을 찾을 수 없습니다.");
            return ResponseEntity.notFound().build();
        }
        
        // 작성자만 삭제 가능
        if (existing.getWriterNo() != user.getNo()) {
            response.put("success", false);
            response.put("message", "삭제 권한이 없습니다.");
            return ResponseEntity.status(403).body(response);
        }
        
        int result = commentService.delete(no);
        
        if (result > 0) {
            response.put("success", true);
            response.put("message", "댓글이 삭제되었습니다.");
        } else {
            response.put("success", false);
            response.put("message", "댓글 삭제에 실패했습니다.");
        }
        
        return ResponseEntity.ok(response);
    }
}
