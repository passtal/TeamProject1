package com.aloha.sample.controller;

import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.aloha.sample.dto.Board;
import com.aloha.sample.dto.Club;
import com.aloha.sample.dto.ClubMember;
import com.aloha.sample.dto.Comment;
import com.aloha.sample.dto.User;
import com.aloha.sample.service.BoardService;
import com.aloha.sample.service.ClubService;
import com.aloha.sample.service.CommentService;
import com.aloha.sample.service.UserService;

/**
 * 게시판 컨트롤러
 */
@Controller
@RequestMapping("/club/{clubNo}/board")
public class BoardController {

    @Autowired
    private BoardService boardService;
    
    @Autowired
    private ClubService clubService;
    
    @Autowired
    private CommentService commentService;
    
    @Autowired
    private UserService userService;

    /**
     * 게시글 목록
     */
    @GetMapping
    public String list(@PathVariable("clubNo") int clubNo,
                      @RequestParam(value = "page", defaultValue = "1") int page,
                      Principal principal,
                      Model model) {
        // 멤버 확인
        if (!isMember(clubNo, principal)) {
            return "redirect:/club/" + clubNo;
        }
        
        Club club = clubService.selectByNo(clubNo);
        List<Board> boards = boardService.listByClub(clubNo);
        List<Board> notices = boardService.listNotices(clubNo);
        
        model.addAttribute("club", club);
        model.addAttribute("boards", boards);
        model.addAttribute("notices", notices);
        
        return "board/list";
    }
    
    /**
     * 게시글 상세
     */
    @GetMapping("/{no}")
    public String detail(@PathVariable("clubNo") int clubNo,
                        @PathVariable("no") int no,
                        Principal principal,
                        Model model) {
        if (!isMember(clubNo, principal)) {
            return "redirect:/club/" + clubNo;
        }
        
        boardService.incrementViewCount(no);
        
        Club club = clubService.selectByNo(clubNo);
        Board board = boardService.selectByNo(no);
        List<Comment> comments = commentService.listByBoard(no);
        
        User currentUser = userService.selectByUserId(principal.getName());
        
        model.addAttribute("club", club);
        model.addAttribute("board", board);
        model.addAttribute("comments", comments);
        model.addAttribute("isWriter", board.getWriterNo() == currentUser.getNo());
        model.addAttribute("isHost", club.getHostNo() == currentUser.getNo());
        
        return "board/detail";
    }
    
    /**
     * 게시글 작성 페이지
     */
    @GetMapping("/write")
    public String write(@PathVariable("clubNo") int clubNo,
                       Principal principal,
                       Model model) {
        if (!isMember(clubNo, principal)) {
            return "redirect:/club/" + clubNo;
        }
        
        Club club = clubService.selectByNo(clubNo);
        User user = userService.selectByUserId(principal.getName());
        boolean isHost = club.getHostNo() == user.getNo();
        
        model.addAttribute("club", club);
        model.addAttribute("board", new Board());
        model.addAttribute("isHost", isHost);
        
        return "board/write";
    }
    
    /**
     * 게시글 작성 처리
     */
    @PostMapping("/write")
    public String writePro(@PathVariable("clubNo") int clubNo,
                          Board board,
                          @RequestParam(value = "isNotice", defaultValue = "N") String isNotice,
                          Principal principal,
                          RedirectAttributes rttr) {
        if (!isMember(clubNo, principal)) {
            return "redirect:/club/" + clubNo;
        }
        
        User user = userService.selectByUserId(principal.getName());
        Club club = clubService.selectByNo(clubNo);
        
        board.setClubNo(clubNo);
        board.setWriterNo(user.getNo());
        
        // 호스트만 공지 작성 가능
        if (club.getHostNo() == user.getNo()) {
            board.setIsNotice(isNotice);
        } else {
            board.setIsNotice("N");
        }
        
        int result = boardService.insert(board);
        
        if (result > 0) {
            rttr.addFlashAttribute("message", "게시글이 작성되었습니다.");
            return "redirect:/club/" + clubNo + "/board/" + board.getNo();
        }
        
        rttr.addFlashAttribute("error", "작성에 실패했습니다.");
        return "redirect:/club/" + clubNo + "/board/write";
    }
    
    /**
     * 게시글 수정 페이지
     */
    @GetMapping("/{no}/edit")
    public String edit(@PathVariable("clubNo") int clubNo,
                      @PathVariable("no") int no,
                      Principal principal,
                      Model model) {
        if (!isMember(clubNo, principal)) {
            return "redirect:/club/" + clubNo;
        }
        
        Board board = boardService.selectByNo(no);
        User user = userService.selectByUserId(principal.getName());
        Club club = clubService.selectByNo(clubNo);
        
        // 작성자 또는 호스트만 수정 가능
        if (board.getWriterNo() != user.getNo() && club.getHostNo() != user.getNo()) {
            return "redirect:/club/" + clubNo + "/board/" + no;
        }
        
        model.addAttribute("club", club);
        model.addAttribute("board", board);
        model.addAttribute("isHost", club.getHostNo() == user.getNo());
        
        return "board/edit";
    }
    
    /**
     * 게시글 수정 처리
     */
    @PostMapping("/{no}/edit")
    public String editPro(@PathVariable("clubNo") int clubNo,
                         @PathVariable("no") int no,
                         Board board,
                         @RequestParam(value = "isNotice", defaultValue = "N") String isNotice,
                         Principal principal,
                         RedirectAttributes rttr) {
        Board existingBoard = boardService.selectByNo(no);
        User user = userService.selectByUserId(principal.getName());
        Club club = clubService.selectByNo(clubNo);
        
        if (existingBoard.getWriterNo() != user.getNo() && club.getHostNo() != user.getNo()) {
            return "redirect:/club/" + clubNo + "/board/" + no;
        }
        
        board.setNo(no);
        if (club.getHostNo() == user.getNo()) {
            board.setIsNotice(isNotice);
        }
        
        int result = boardService.update(board);
        
        if (result > 0) {
            rttr.addFlashAttribute("message", "게시글이 수정되었습니다.");
        } else {
            rttr.addFlashAttribute("error", "수정에 실패했습니다.");
        }
        
        return "redirect:/club/" + clubNo + "/board/" + no;
    }
    
    /**
     * 게시글 삭제
     */
    @PostMapping("/{no}/delete")
    public String delete(@PathVariable("clubNo") int clubNo,
                        @PathVariable("no") int no,
                        Principal principal,
                        RedirectAttributes rttr) {
        Board board = boardService.selectByNo(no);
        User user = userService.selectByUserId(principal.getName());
        Club club = clubService.selectByNo(clubNo);
        
        if (board.getWriterNo() != user.getNo() && club.getHostNo() != user.getNo()) {
            return "redirect:/club/" + clubNo + "/board/" + no;
        }
        
        boardService.delete(no);
        rttr.addFlashAttribute("message", "게시글이 삭제되었습니다.");
        
        return "redirect:/club/" + clubNo + "/board";
    }
    
    /**
     * 멤버 여부 확인 (승인된 멤버만)
     */
    private boolean isMember(int clubNo, Principal principal) {
        if (principal == null) return false;
        
        User user = userService.selectByUserId(principal.getName());
        ClubMember member = clubService.selectMember(clubNo, user.getNo());
        
        return member != null && "APPROVED".equals(member.getStatus());
    }
}
