package com.aloha.sample.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.aloha.sample.dto.Banner;
import com.aloha.sample.dto.Club;
import com.aloha.sample.service.BannerService;
import com.aloha.sample.service.ClubService;

import lombok.extern.slf4j.Slf4j;

/**
 * 홈 컨트롤러
 */
@Slf4j
@Controller
public class HomeController {

    @Autowired
    private ClubService clubService;
    
    @Autowired
    private BannerService bannerService;

    /**
     * 메인 페이지
     */
    @GetMapping("/")
    public String index(Model model) {
        try {
            // 인기 모임 (조회수 상위)
            List<Club> popularClubs = clubService.listPopular(8);
            model.addAttribute("popularClubs", popularClubs);
            
            // 최신 모임
            List<Club> latestClubs = clubService.listLatest(8);
            model.addAttribute("latestClubs", latestClubs);
            
            // 마감 임박 모임
            List<Club> upcomingClubs = clubService.listUpcoming(4);
            model.addAttribute("upcomingClubs", upcomingClubs);
            
            // 활성 배너
            List<Banner> banners = bannerService.listActive();
            model.addAttribute("banners", banners);
        } catch (Exception e) {
            log.error("메인 페이지 데이터 로드 실패: {}", e.getMessage());
            model.addAttribute("popularClubs", new ArrayList<>());
            model.addAttribute("latestClubs", new ArrayList<>());
            model.addAttribute("upcomingClubs", new ArrayList<>());
            model.addAttribute("banners", new ArrayList<>());
        }
        
        return "index";
    }
    
    /**
     * 소개 페이지
     */
    @GetMapping("/about")
    public String about() {
        return "about";
    }
}
