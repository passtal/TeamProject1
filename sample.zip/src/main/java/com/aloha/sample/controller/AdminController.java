package com.aloha.sample.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.aloha.sample.dto.Banner;
import com.aloha.sample.dto.Category;
import com.aloha.sample.dto.Club;
import com.aloha.sample.dto.Report;
import com.aloha.sample.dto.SubCategory;
import com.aloha.sample.dto.User;
import com.aloha.sample.dto.UserBan;
import com.aloha.sample.service.BannerService;
import com.aloha.sample.service.CategoryService;
import com.aloha.sample.service.ClubService;
import com.aloha.sample.service.ReportService;
import com.aloha.sample.service.UserService;

/**
 * 관리자 컨트롤러
 */
@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private ClubService clubService;
    
    @Autowired
    private CategoryService categoryService;
    
    @Autowired
    private BannerService bannerService;
    
    @Autowired
    private ReportService reportService;

    /**
     * 관리자 대시보드
     */
    @GetMapping
    public String dashboard(Model model) {
        // 통계 정보
        model.addAttribute("userCount", userService.count());
        model.addAttribute("clubCount", clubService.count());
        
        return "admin/dashboard";
    }
    
    // ===== 회원 관리 =====
    
    @GetMapping("/user")
    public String userList(Model model) {
        List<User> users = userService.list();
        model.addAttribute("users", users);
        return "admin/user/list";
    }
    
    @GetMapping("/user/{no}")
    public String userDetail(@PathVariable("no") int no, Model model) {
        User user = userService.selectByNo(no);
        List<UserBan> bans = reportService.listBanByUser(no);
        
        model.addAttribute("user", user);
        model.addAttribute("bans", bans);
        
        return "admin/user/detail";
    }
    
    @PostMapping("/user/{no}/ban")
    public String banUser(@PathVariable("no") int no,
                         @RequestParam String reason,
                         @RequestParam String banType,
                         RedirectAttributes rttr) {
        User user = userService.selectByNo(no);
        
        UserBan ban = new UserBan();
        ban.setUserNo(no);
        ban.setReason(reason);
        ban.setReportCountAtBan(user.getReportCount());
        ban.setBanType(banType);
        
        reportService.insertBan(ban);
        rttr.addFlashAttribute("message", "회원이 차단되었습니다.");
        
        return "redirect:/admin/user/" + no;
    }
    
    @PostMapping("/user/{no}/unban")
    public String unbanUser(@PathVariable("no") int no,
                           @RequestParam int banNo,
                           RedirectAttributes rttr) {
        reportService.releaseBan(banNo);
        rttr.addFlashAttribute("message", "차단이 해제되었습니다.");
        return "redirect:/admin/user/" + no;
    }
    
    // ===== 모임 관리 =====
    
    @GetMapping("/club")
    public String clubList(Model model) {
        List<Club> clubs = clubService.list();
        model.addAttribute("clubs", clubs);
        return "admin/club/list";
    }
    
    @PostMapping("/club/{no}/delete")
    public String deleteClub(@PathVariable("no") int no, RedirectAttributes rttr) {
        clubService.delete(no);
        rttr.addFlashAttribute("message", "모임이 삭제되었습니다.");
        return "redirect:/admin/club";
    }
    
    // ===== 카테고리 관리 =====
    
    @GetMapping("/category")
    public String categoryList(Model model) {
        List<Category> categories = categoryService.list();
        model.addAttribute("categories", categories);
        return "admin/category/list";
    }
    
    @PostMapping("/category")
    public String createCategory(Category category, RedirectAttributes rttr) {
        categoryService.insert(category);
        rttr.addFlashAttribute("message", "카테고리가 생성되었습니다.");
        return "redirect:/admin/category";
    }
    
    @PostMapping("/category/{no}/update")
    public String updateCategory(@PathVariable("no") int no, Category category, RedirectAttributes rttr) {
        category.setNo(no);
        categoryService.update(category);
        rttr.addFlashAttribute("message", "카테고리가 수정되었습니다.");
        return "redirect:/admin/category";
    }
    
    @PostMapping("/category/{no}/delete")
    public String deleteCategory(@PathVariable("no") int no, RedirectAttributes rttr) {
        categoryService.delete(no);
        rttr.addFlashAttribute("message", "카테고리가 삭제되었습니다.");
        return "redirect:/admin/category";
    }
    
    @PostMapping("/category/{categoryNo}/sub")
    public String createSubCategory(@PathVariable("categoryNo") int categoryNo, 
                                   SubCategory subCategory, 
                                   RedirectAttributes rttr) {
        subCategory.setCategoryNo(categoryNo);
        categoryService.insertSub(subCategory);
        rttr.addFlashAttribute("message", "서브카테고리가 생성되었습니다.");
        return "redirect:/admin/category";
    }
    
    // ===== 배너 관리 =====
    
    @GetMapping("/banner")
    public String bannerList(Model model) {
        List<Banner> banners = bannerService.list();
        model.addAttribute("banners", banners);
        return "admin/banner/list";
    }
    
    @GetMapping("/banner/create")
    public String bannerCreate(Model model) {
        model.addAttribute("banner", new Banner());
        return "admin/banner/create";
    }
    
    @PostMapping("/banner/create")
    public String bannerCreatePro(Banner banner, RedirectAttributes rttr) {
        bannerService.insert(banner);
        rttr.addFlashAttribute("message", "배너가 생성되었습니다.");
        return "redirect:/admin/banner";
    }
    
    @GetMapping("/banner/{no}/edit")
    public String bannerEdit(@PathVariable("no") int no, Model model) {
        Banner banner = bannerService.selectByNo(no);
        model.addAttribute("banner", banner);
        return "admin/banner/edit";
    }
    
    @PostMapping("/banner/{no}/edit")
    public String bannerEditPro(@PathVariable("no") int no, Banner banner, RedirectAttributes rttr) {
        banner.setNo(no);
        bannerService.update(banner);
        rttr.addFlashAttribute("message", "배너가 수정되었습니다.");
        return "redirect:/admin/banner";
    }
    
    @PostMapping("/banner/{no}/delete")
    public String bannerDelete(@PathVariable("no") int no, RedirectAttributes rttr) {
        bannerService.delete(no);
        rttr.addFlashAttribute("message", "배너가 삭제되었습니다.");
        return "redirect:/admin/banner";
    }
    
    @PostMapping("/banner/{no}/toggle")
    public String bannerToggle(@PathVariable("no") int no, RedirectAttributes rttr) {
        Banner banner = bannerService.selectByNo(no);
        String newStatus = "Y".equals(banner.getIsActive()) ? "N" : "Y";
        bannerService.updateActive(no, newStatus);
        rttr.addFlashAttribute("message", "배너 상태가 변경되었습니다.");
        return "redirect:/admin/banner";
    }
    
    // ===== 신고 관리 =====
    
    @GetMapping("/report")
    public String reportList(Model model) {
        List<Report> reports = reportService.list();
        model.addAttribute("reports", reports);
        return "admin/report/list";
    }
    
    @GetMapping("/report/{no}")
    public String reportDetail(@PathVariable("no") int no, Model model) {
        Report report = reportService.selectByNo(no);
        model.addAttribute("report", report);
        return "admin/report/detail";
    }
    
    @PostMapping("/report/{no}/process")
    public String processReport(@PathVariable("no") int no,
                               @RequestParam boolean shouldBan,
                               @RequestParam(required = false) String banType,
                               RedirectAttributes rttr) {
        reportService.processReport(no, shouldBan, banType);
        rttr.addFlashAttribute("message", "신고가 처리되었습니다.");
        return "redirect:/admin/report";
    }
}
