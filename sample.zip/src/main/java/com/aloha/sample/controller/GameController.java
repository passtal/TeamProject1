package com.aloha.sample.controller;

import java.security.Principal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.aloha.sample.dto.Club;
import com.aloha.sample.dto.ClubMember;
import com.aloha.sample.dto.Game;
import com.aloha.sample.dto.User;
import com.aloha.sample.service.ClubService;
import com.aloha.sample.service.GameService;
import com.aloha.sample.service.UserService;

/**
 * 게임 컨트롤러
 */
@Controller
@RequestMapping("/club/{clubNo}/game")
public class GameController {

    @Autowired
    private GameService gameService;
    
    @Autowired
    private ClubService clubService;
    
    @Autowired
    private UserService userService;

    /**
     * 게임 목록 페이지
     */
    @GetMapping
    public String list(@PathVariable("clubNo") int clubNo,
                      Principal principal,
                      Model model) {
        if (!isMember(clubNo, principal)) {
            return "redirect:/club/" + clubNo;
        }
        
        Club club = clubService.selectByNo(clubNo);
        List<Game> games = gameService.listByClub(clubNo);
        
        model.addAttribute("club", club);
        model.addAttribute("games", games);
        
        return "game/list";
    }
    
    /**
     * 게임 실행 페이지
     */
    @GetMapping("/play")
    public String play(@PathVariable("clubNo") int clubNo,
                      Principal principal,
                      Model model) {
        if (!isMember(clubNo, principal)) {
            return "redirect:/club/" + clubNo;
        }
        
        Club club = clubService.selectByNo(clubNo);
        List<ClubMember> members = clubService.listMembers(clubNo);
        
        model.addAttribute("club", club);
        model.addAttribute("members", members);
        
        return "game/play";
    }
    
    /**
     * 게임 실행 (AJAX)
     */
    @PostMapping("/play")
    @ResponseBody
    public Map<String, Object> playGame(@PathVariable("clubNo") int clubNo,
                                        Game game,
                                        Principal principal) {
        User user = userService.selectByUserId(principal.getName());
        
        game.setClubNo(clubNo);
        game.setCreatedBy(user.getNo());
        
        return gameService.playGame(game);
    }
    
    /**
     * 게임 결과 조회
     */
    @GetMapping("/{no}")
    public String detail(@PathVariable("clubNo") int clubNo,
                        @PathVariable("no") int no,
                        Principal principal,
                        Model model) {
        if (!isMember(clubNo, principal)) {
            return "redirect:/club/" + clubNo;
        }
        
        Club club = clubService.selectByNo(clubNo);
        Game game = gameService.selectByNo(no);
        
        model.addAttribute("club", club);
        model.addAttribute("game", game);
        
        return "game/detail";
    }
    
    /**
     * 게임 삭제
     */
    @PostMapping("/{no}/delete")
    public String delete(@PathVariable("clubNo") int clubNo,
                        @PathVariable("no") int no,
                        Principal principal,
                        RedirectAttributes rttr) {
        User user = userService.selectByUserId(principal.getName());
        Game game = gameService.selectByNo(no);
        
        // 생성자만 삭제 가능
        if (game.getCreatedBy() != user.getNo()) {
            rttr.addFlashAttribute("error", "삭제 권한이 없습니다.");
            return "redirect:/club/" + clubNo + "/game";
        }
        
        gameService.delete(no);
        rttr.addFlashAttribute("message", "게임이 삭제되었습니다.");
        
        return "redirect:/club/" + clubNo + "/game";
    }
    
    /**
     * 멤버 여부 확인
     */
    private boolean isMember(int clubNo, Principal principal) {
        if (principal == null) return false;
        
        User user = userService.selectByUserId(principal.getName());
        ClubMember member = clubService.selectMember(clubNo, user.getNo());
        
        return member != null && "APPROVED".equals(member.getStatus());
    }
}
