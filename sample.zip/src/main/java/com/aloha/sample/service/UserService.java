package com.aloha.sample.service;

import java.util.List;

import com.aloha.sample.dto.Auth;
import com.aloha.sample.dto.User;

/**
 * 회원 서비스 인터페이스
 */
public interface UserService {
    
    // 회원 목록 조회
    List<User> list();
    
    // 회원 단건 조회 (no)
    User selectByNo(int no);
    
    // 회원 단건 조회 (userId)
    User selectByUserId(String userId);
    
    // 회원 단건 조회 (username)
    User selectByUsername(String username);
    
    // 회원 등록
    int insert(User user);
    
    // 회원 수정
    int update(User user);
    
    // 회원 삭제
    int delete(int no);
    
    // 아이디 중복 확인
    boolean isUserIdAvailable(String userId);
    
    // 닉네임 중복 확인
    boolean isUsernameAvailable(String username);
    
    // 회원 수 조회
    int count();
    
    // 권한 등록
    int insertAuth(Auth auth);
}
