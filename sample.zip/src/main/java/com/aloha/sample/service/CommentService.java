package com.aloha.sample.service;

import java.util.List;

import com.aloha.sample.dto.Comment;

/**
 * 댓글 서비스 인터페이스
 */
public interface CommentService {
    
    // 댓글 목록 (게시글별)
    List<Comment> listByBoard(int boardNo);
    
    // 작성자별 댓글 목록
    List<Comment> listByWriter(int writerNo);
    
    // 댓글 단건 조회
    Comment selectByNo(int no);
    
    // 댓글 등록
    int insert(Comment comment);
    
    // 댓글 수정
    int update(Comment comment);
    
    // 댓글 삭제
    int delete(int no);
}
