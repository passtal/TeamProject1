package com.aloha.sample.service;

import java.util.List;
import java.util.Map;

import com.aloha.sample.dto.Game;

/**
 * 게임 서비스 인터페이스
 */
public interface GameService {
    
    // 게임 목록 (모임별)
    List<Game> listByClub(int clubNo);
    
    // 최근 게임 목록
    List<Game> listRecentByClub(int clubNo, int limit);
    
    // 게임 단건 조회
    Game selectByNo(int no);
    
    // 게임 등록
    int insert(Game game);
    
    // 게임 실행 (결과 생성)
    Map<String, Object> playGame(Game game);
    
    // 게임 삭제
    int delete(int no);
}
