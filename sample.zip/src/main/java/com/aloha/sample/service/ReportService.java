package com.aloha.sample.service;

import java.util.List;

import com.aloha.sample.dto.Report;
import com.aloha.sample.dto.UserBan;

/**
 * 신고/차단 서비스 인터페이스
 */
public interface ReportService {
    
    // ===== 신고 =====
    
    // 신고 목록 (전체)
    List<Report> list();
    
    // 모임별 신고 목록
    List<Report> listByClub(int clubNo);
    
    // 피신고자별 신고 목록
    List<Report> listByTarget(int targetNo);
    
    // 신고 단건 조회
    Report selectByNo(int no);
    
    // 신고 등록
    int insert(Report report);
    
    // 신고 삭제
    int delete(int no);
    
    // 중복 신고 여부 확인
    boolean isDuplicate(int clubNo, int reporterNo, int targetNo);
    
    // ===== 차단 =====
    
    // 차단 이력 목록
    List<UserBan> listBan();
    
    // 회원별 차단 이력
    List<UserBan> listBanByUser(int userNo);
    
    // 활성 차단 조회
    UserBan selectActiveBan(int userNo);
    
    // 차단 등록
    int insertBan(UserBan ban);
    
    // 차단 해제
    int releaseBan(int banNo);
    
    // 신고 처리 (차단 여부 결정)
    void processReport(int reportNo, boolean shouldBan, String banType);
}
