package com.aloha.sample.service;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aloha.sample.dao.ReportMapper;
import com.aloha.sample.dao.UserMapper;
import com.aloha.sample.dto.Report;
import com.aloha.sample.dto.User;
import com.aloha.sample.dto.UserBan;

/**
 * 신고/차단 서비스 구현체
 */
@Service
public class ReportServiceImpl implements ReportService {

    @Autowired
    private ReportMapper reportMapper;
    
    @Autowired
    private UserMapper userMapper;

    // ===== 신고 =====

    @Override
    public List<Report> list() {
        return reportMapper.list();
    }

    @Override
    public List<Report> listByClub(int clubNo) {
        return reportMapper.listByClub(clubNo);
    }

    @Override
    public List<Report> listByTarget(int targetNo) {
        return reportMapper.listByTarget(targetNo);
    }

    @Override
    public Report selectByNo(int no) {
        return reportMapper.selectByNo(no);
    }

    @Override
    @Transactional
    public int insert(Report report) {
        int result = reportMapper.insert(report);
        
        // 피신고자 신고 횟수 증가
        if (result > 0) {
            userMapper.incrementReportCount(report.getTargetNo());
            
            // 자동 차단 체크 (5회 이상)
            User target = userMapper.selectByNo(report.getTargetNo());
            if (target != null && target.getReportCount() >= 5) {
                // 임시 차단 처리
                UserBan ban = new UserBan();
                ban.setUserNo(target.getNo());
                ban.setReason("신고 누적 5회 이상 - 자동 차단");
                ban.setReportCountAtBan(target.getReportCount());
                ban.setBanType("TEMPORARY");
                
                // 7일 후 해제
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.DAY_OF_MONTH, 7);
                ban.setBanEndDate(cal.getTime());
                
                reportMapper.insertBan(ban);
                userMapper.updateBanned(target.getNo(), "Y");
            }
        }
        
        return result;
    }

    @Override
    public int delete(int no) {
        return reportMapper.delete(no);
    }

    @Override
    public boolean isDuplicate(int clubNo, int reporterNo, int targetNo) {
        return reportMapper.countByClubReporterTarget(clubNo, reporterNo, targetNo) > 0;
    }

    // ===== 차단 =====

    @Override
    public List<UserBan> listBan() {
        return reportMapper.listBan();
    }

    @Override
    public List<UserBan> listBanByUser(int userNo) {
        return reportMapper.listBanByUser(userNo);
    }

    @Override
    public UserBan selectActiveBan(int userNo) {
        return reportMapper.selectActiveBan(userNo);
    }

    @Override
    @Transactional
    public int insertBan(UserBan ban) {
        int result = reportMapper.insertBan(ban);
        if (result > 0) {
            userMapper.updateBanned(ban.getUserNo(), "Y");
        }
        return result;
    }

    @Override
    @Transactional
    public int releaseBan(int banNo) {
        UserBan ban = reportMapper.selectBanByNo(banNo);
        int result = reportMapper.updateBanActive(banNo, "N");
        if (result > 0 && ban != null) {
            userMapper.updateBanned(ban.getUserNo(), "N");
        }
        return result;
    }

    @Override
    @Transactional
    public void processReport(int reportNo, boolean shouldBan, String banType) {
        Report report = reportMapper.selectByNo(reportNo);
        if (report == null) return;
        
        if (shouldBan) {
            User target = userMapper.selectByNo(report.getTargetNo());
            
            UserBan ban = new UserBan();
            ban.setUserNo(report.getTargetNo());
            ban.setReason("관리자 처리: " + report.getReason());
            ban.setReportCountAtBan(target != null ? target.getReportCount() : 0);
            ban.setBanType(banType);
            
            if ("TEMPORARY".equals(banType)) {
                Calendar cal = Calendar.getInstance();
                cal.add(Calendar.DAY_OF_MONTH, 7);
                ban.setBanEndDate(cal.getTime());
            }
            
            reportMapper.insertBan(ban);
            userMapper.updateBanned(report.getTargetNo(), "Y");
        }
    }
}
