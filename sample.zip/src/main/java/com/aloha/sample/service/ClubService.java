package com.aloha.sample.service;

import java.util.List;

import com.aloha.sample.dto.Club;
import com.aloha.sample.dto.ClubMember;

/**
 * 모임 서비스 인터페이스
 */
public interface ClubService {
    
    // 모임 목록 조회
    List<Club> list();
    
    // 카테고리별 모임 목록
    List<Club> listByCategory(int categoryNo);
    
    // 소분류별 모임 목록
    List<Club> listBySubCategory(int subCategoryNo);
    
    // 모임장별 모임 목록
    List<Club> listByHost(int hostNo);
    
    // 인기 모임 목록
    List<Club> listPopular(int limit);
    
    // 최신 모임 목록
    List<Club> listRecent(int limit);
    
    // 모임 검색
    List<Club> search(String keyword);
    
    // 모임 단건 조회
    Club selectByNo(int no);
    
    // 모임 등록
    int insert(Club club);
    
    // 모임 수정
    int update(Club club);
    
    // 모임 삭제
    int delete(int no);
    
    // 조회수 증가
    int incrementViewCount(int no);
    
    // 모임 상태 변경
    int updateStatus(int no, String status);
    
    // ===== 멤버 관련 =====
    
    // 멤버 목록 조회
    List<ClubMember> listMembers(int clubNo);
    
    // 승인된 멤버 목록
    List<ClubMember> listApprovedMembers(int clubNo);
    
    // 대기중 멤버 목록
    List<ClubMember> listPendingMembers(int clubNo);
    
    // 회원의 가입 모임 목록
    List<ClubMember> listByUser(int userNo);
    
    // 가입 신청
    int joinClub(int clubNo, int userNo);
    
    // 가입 승인
    int approveMember(int memberNo);
    
    // 가입 거절
    int rejectMember(int memberNo);
    
    // 모임 탈퇴
    int leaveClub(int clubNo, int userNo);
    
    // 멤버 여부 확인
    boolean isMember(int clubNo, int userNo);
    
    // 멤버 상태 조회
    ClubMember getMemberStatus(int clubNo, int userNo);
    
    // 모임 수 조회
    int count();
    
    // 마감 임박 모임
    List<Club> listUpcoming(int limit);
    
    // 최신 모임
    List<Club> listLatest(int limit);
    
    // 멤버 조회
    ClubMember selectMember(int clubNo, int userNo);
    
    // 멤버 등록
    int insertMember(ClubMember member);
    
    // 멤버 삭제
    int deleteMember(int clubNo, int userNo);
    
    // 멤버 상태 변경
    int updateMemberStatus(int memberNo, String status);
    
    // 멤버 수 증가
    int incrementMemberCount(int clubNo);
    
    // 멤버 수 감소
    int decrementMemberCount(int clubNo);
}
