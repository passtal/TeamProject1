package com.aloha.sample.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aloha.sample.dao.GameMapper;
import com.aloha.sample.dto.Game;

/**
 * 게임 서비스 구현체
 */
@Service
public class GameServiceImpl implements GameService {

    @Autowired
    private GameMapper gameMapper;
    
    private Random random = new Random();

    @Override
    public List<Game> listByClub(int clubNo) {
        return gameMapper.listByClub(clubNo);
    }

    @Override
    public List<Game> listRecentByClub(int clubNo, int limit) {
        return gameMapper.listRecentByClub(clubNo, limit);
    }

    @Override
    public Game selectByNo(int no) {
        return gameMapper.selectByNo(no);
    }

    @Override
    public int insert(Game game) {
        return gameMapper.insert(game);
    }

    @Override
    @Transactional
    public Map<String, Object> playGame(Game game) {
        Map<String, Object> result = new HashMap<>();
        String gameResult = "";
        
        String gameType = game.getGameType();
        String options = game.getOptions();
        
        switch (gameType) {
            case "ROULETTE":
                // 룰렛: options에서 랜덤 선택
                if (options != null && !options.isEmpty()) {
                    String[] items = options.split(",");
                    if (items.length > 0) {
                        gameResult = items[random.nextInt(items.length)].trim();
                    }
                }
                break;
                
            case "LADDER":
                // 사다리: 랜덤 결과
                if (options != null && !options.isEmpty()) {
                    String[] items = options.split(",");
                    if (items.length > 0) {
                        gameResult = items[random.nextInt(items.length)].trim();
                    }
                }
                break;
                
            case "RANDOM_PICK":
                // 랜덤뽑기: 주사위 또는 동전
                int dice = random.nextInt(6) + 1;
                gameResult = String.valueOf(dice);
                break;
                
            default:
                gameResult = "알 수 없는 게임";
        }
        
        // 게임 저장
        game.setResult(gameResult);
        int insertResult = gameMapper.insert(game);
        
        result.put("success", insertResult > 0);
        result.put("result", gameResult);
        result.put("gameNo", game.getNo());
        
        return result;
    }

    @Override
    public int delete(int no) {
        return gameMapper.delete(no);
    }
}
