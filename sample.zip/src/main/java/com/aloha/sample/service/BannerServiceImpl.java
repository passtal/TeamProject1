package com.aloha.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.aloha.sample.dao.BannerMapper;
import com.aloha.sample.dto.Banner;

/**
 * 배너 서비스 구현체
 */
@Service
public class BannerServiceImpl implements BannerService {

    @Autowired
    private BannerMapper bannerMapper;

    @Override
    public List<Banner> list() {
        return bannerMapper.list();
    }

    @Override
    public List<Banner> listActive() {
        return bannerMapper.listActive();
    }

    @Override
    public List<Banner> listByPosition(String position) {
        return bannerMapper.listByPosition(position);
    }

    @Override
    public Banner selectByNo(int no) {
        return bannerMapper.selectByNo(no);
    }

    @Override
    public int insert(Banner banner) {
        return bannerMapper.insert(banner);
    }

    @Override
    public int update(Banner banner) {
        return bannerMapper.update(banner);
    }

    @Override
    public int delete(int no) {
        return bannerMapper.delete(no);
    }

    @Override
    public int incrementClickCount(int no) {
        return bannerMapper.incrementClickCount(no);
    }

    @Override
    public int updateActive(int no, String isActive) {
        return bannerMapper.updateActive(no, isActive);
    }
}
