package com.aloha.sample.service;

import java.util.List;

import com.aloha.sample.dto.Banner;

/**
 * 배너 서비스 인터페이스
 */
public interface BannerService {
    
    // 배너 목록 조회
    List<Banner> list();
    
    // 활성 배너 목록
    List<Banner> listActive();
    
    // 위치별 배너 목록
    List<Banner> listByPosition(String position);
    
    // 배너 단건 조회
    Banner selectByNo(int no);
    
    // 배너 등록
    int insert(Banner banner);
    
    // 배너 수정
    int update(Banner banner);
    
    // 배너 삭제
    int delete(int no);
    
    // 클릭 수 증가
    int incrementClickCount(int no);
    
    // 활성화 상태 변경
    int updateActive(int no, String isActive);
}
