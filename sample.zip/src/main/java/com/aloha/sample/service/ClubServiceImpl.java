package com.aloha.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aloha.sample.dao.ClubMapper;
import com.aloha.sample.dao.MemberMapper;
import com.aloha.sample.dto.Club;
import com.aloha.sample.dto.ClubMember;

/**
 * 모임 서비스 구현체
 */
@Service
public class ClubServiceImpl implements ClubService {

    @Autowired
    private ClubMapper clubMapper;
    
    @Autowired
    private MemberMapper memberMapper;

    @Override
    public List<Club> list() {
        return clubMapper.list();
    }

    @Override
    public List<Club> listByCategory(int categoryNo) {
        return clubMapper.listByCategory(categoryNo);
    }

    @Override
    public List<Club> listBySubCategory(int subCategoryNo) {
        return clubMapper.listBySubCategory(subCategoryNo);
    }

    @Override
    public List<Club> listByHost(int hostNo) {
        return clubMapper.listByHost(hostNo);
    }

    @Override
    public List<Club> listPopular(int limit) {
        return clubMapper.listPopular(limit);
    }

    @Override
    public List<Club> listRecent(int limit) {
        return clubMapper.listRecent(limit);
    }

    @Override
    public List<Club> search(String keyword) {
        return clubMapper.search(keyword);
    }

    @Override
    public Club selectByNo(int no) {
        return clubMapper.selectByNo(no);
    }

    @Override
    @Transactional
    public int insert(Club club) {
        int result = clubMapper.insert(club);
        
        // 모임장 자동 가입 (승인 상태)
        if (result > 0) {
            ClubMember member = new ClubMember();
            member.setClubNo(club.getNo());
            member.setUserNo(club.getHostNo());
            member.setStatus("APPROVED");
            memberMapper.insert(member);
        }
        
        return result;
    }

    @Override
    public int update(Club club) {
        return clubMapper.update(club);
    }

    @Override
    public int delete(int no) {
        return clubMapper.delete(no);
    }

    @Override
    public int incrementViewCount(int no) {
        return clubMapper.incrementViewCount(no);
    }

    @Override
    public int updateStatus(int no, String status) {
        return clubMapper.updateStatus(no, status);
    }

    // ===== 멤버 관련 =====

    @Override
    public List<ClubMember> listMembers(int clubNo) {
        return memberMapper.listByClub(clubNo);
    }

    @Override
    public List<ClubMember> listApprovedMembers(int clubNo) {
        return memberMapper.listApproved(clubNo);
    }

    @Override
    public List<ClubMember> listPendingMembers(int clubNo) {
        return memberMapper.listPending(clubNo);
    }

    @Override
    public List<ClubMember> listByUser(int userNo) {
        return memberMapper.listByUser(userNo);
    }

    @Override
    public int joinClub(int clubNo, int userNo) {
        ClubMember member = new ClubMember();
        member.setClubNo(clubNo);
        member.setUserNo(userNo);
        member.setStatus("PENDING");
        return memberMapper.insert(member);
    }

    @Override
    @Transactional
    public int approveMember(int memberNo) {
        ClubMember member = memberMapper.selectByNo(memberNo);
        if (member != null) {
            clubMapper.incrementCurrentMembers(member.getClubNo());
        }
        return memberMapper.updateStatus(memberNo, "APPROVED");
    }

    @Override
    public int rejectMember(int memberNo) {
        return memberMapper.updateStatus(memberNo, "REJECTED");
    }

    @Override
    @Transactional
    public int leaveClub(int clubNo, int userNo) {
        clubMapper.decrementCurrentMembers(clubNo);
        return memberMapper.deleteByClubAndUser(clubNo, userNo);
    }

    @Override
    public boolean isMember(int clubNo, int userNo) {
        return memberMapper.countByClubAndUser(clubNo, userNo) > 0;
    }

    @Override
    public ClubMember getMemberStatus(int clubNo, int userNo) {
        return memberMapper.selectByClubAndUser(clubNo, userNo);
    }
    
    @Override
    public int count() {
        return clubMapper.count();
    }
    
    @Override
    public List<Club> listUpcoming(int limit) {
        return clubMapper.listUpcoming(limit);
    }
    
    @Override
    public List<Club> listLatest(int limit) {
        return clubMapper.listRecent(limit);
    }
    
    @Override
    public ClubMember selectMember(int clubNo, int userNo) {
        return memberMapper.selectByClubAndUser(clubNo, userNo);
    }
    
    @Override
    public int insertMember(ClubMember member) {
        return memberMapper.insert(member);
    }
    
    @Override
    public int deleteMember(int clubNo, int userNo) {
        return memberMapper.deleteByClubAndUser(clubNo, userNo);
    }
    
    @Override
    public int updateMemberStatus(int memberNo, String status) {
        return memberMapper.updateStatus(memberNo, status);
    }
    
    @Override
    public int incrementMemberCount(int clubNo) {
        return clubMapper.incrementCurrentMembers(clubNo);
    }
    
    @Override
    public int decrementMemberCount(int clubNo) {
        return clubMapper.decrementCurrentMembers(clubNo);
    }
}
