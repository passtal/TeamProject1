package com.aloha.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aloha.sample.dao.AuthMapper;
import com.aloha.sample.dao.UserMapper;
import com.aloha.sample.dto.Auth;
import com.aloha.sample.dto.User;

/**
 * 회원 서비스 구현체
 */
@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;
    
    @Autowired
    private AuthMapper authMapper;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public List<User> list() {
        return userMapper.list();
    }

    @Override
    public User selectByNo(int no) {
        return userMapper.selectByNo(no);
    }

    @Override
    public User selectByUserId(String userId) {
        return userMapper.selectByUserId(userId);
    }

    @Override
    public User selectByUsername(String username) {
        return userMapper.selectByUsername(username);
    }

    @Override
    @Transactional
    public int insert(User user) {
        // 비밀번호 암호화
        String encodedPassword = passwordEncoder.encode(user.getPassword());
        user.setPassword(encodedPassword);
        
        // 회원 등록
        int result = userMapper.insert(user);
        
        // 기본 권한 부여 (ROLE_USER)
        if (result > 0) {
            Auth auth = new Auth();
            auth.setUserNo(user.getNo());
            auth.setAuth("ROLE_USER");
            authMapper.insert(auth);
        }
        
        return result;
    }

    @Override
    public int update(User user) {
        return userMapper.update(user);
    }

    @Override
    @Transactional
    public int delete(int no) {
        // 권한 먼저 삭제 (CASCADE로 자동 삭제되지만 명시적으로)
        authMapper.deleteByUserNo(no);
        return userMapper.delete(no);
    }

    @Override
    public boolean isUserIdAvailable(String userId) {
        return userMapper.countByUserId(userId) == 0;
    }

    @Override
    public boolean isUsernameAvailable(String username) {
        return userMapper.countByUsername(username) == 0;
    }
    
    @Override
    public int count() {
        return userMapper.count();
    }
    
    @Override
    public int insertAuth(Auth auth) {
        return authMapper.insert(auth);
    }
}
