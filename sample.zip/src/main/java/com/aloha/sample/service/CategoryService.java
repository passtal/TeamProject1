package com.aloha.sample.service;

import java.util.List;

import com.aloha.sample.dto.Category;
import com.aloha.sample.dto.SubCategory;

/**
 * 카테고리 서비스 인터페이스
 */
public interface CategoryService {
    
    // 대분류 카테고리 목록 조회
    List<Category> list();
    
    // 대분류 카테고리 단건 조회
    Category selectByNo(int no);
    
    // 대분류 카테고리 등록
    int insert(Category category);
    
    // 대분류 카테고리 수정
    int update(Category category);
    
    // 대분류 카테고리 삭제
    int delete(int no);
    
    // 소분류 카테고리 목록 조회
    List<SubCategory> listSubByCategory(int categoryNo);
    
    // 소분류 카테고리 단건 조회
    SubCategory selectSubByNo(int no);
    
    // 소분류 카테고리 등록
    int insertSub(SubCategory subCategory);
    
    // 소분류 카테고리 수정
    int updateSub(SubCategory subCategory);
    
    // 소분류 카테고리 삭제
    int deleteSub(int no);
}
