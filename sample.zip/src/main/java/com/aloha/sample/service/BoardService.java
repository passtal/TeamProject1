package com.aloha.sample.service;

import java.util.List;

import com.aloha.sample.dto.Board;
import com.aloha.sample.dto.BoardImage;

/**
 * 게시판 서비스 인터페이스
 */
public interface BoardService {
    
    // 게시글 목록 (모임별)
    List<Board> listByClub(int clubNo);
    
    // 공지 게시글 목록
    List<Board> listNoticeByClub(int clubNo);
    
    // 공지사항 목록 (단축 메서드)
    List<Board> listNotices(int clubNo);
    
    // 작성자별 게시글 목록
    List<Board> listByWriter(int writerNo);
    
    // 게시글 검색
    List<Board> searchByClub(int clubNo, String keyword);
    
    // 게시글 단건 조회
    Board selectByNo(int no);
    
    // 게시글 등록
    int insert(Board board, List<BoardImage> images);
    
    // 게시글 등록 (이미지 없음)
    int insert(Board board);
    
    // 게시글 수정
    int update(Board board, List<BoardImage> images);
    
    // 게시글 수정 (이미지 없음)
    int update(Board board);
    
    // 게시글 삭제
    int delete(int no);
    
    // 조회수 증가
    int incrementViewCount(int no);
}
