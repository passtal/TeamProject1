package com.aloha.sample.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aloha.sample.dao.BoardMapper;
import com.aloha.sample.dao.ClubMapper;
import com.aloha.sample.dao.CommentMapper;
import com.aloha.sample.dao.LikeMapper;
import com.aloha.sample.dto.BoardLike;
import com.aloha.sample.dto.ClubLike;
import com.aloha.sample.dto.CommentLike;

/**
 * 좋아요 서비스 구현체
 */
@Service
public class LikeServiceImpl implements LikeService {

    @Autowired
    private LikeMapper likeMapper;
    
    @Autowired
    private ClubMapper clubMapper;
    
    @Autowired
    private BoardMapper boardMapper;
    
    @Autowired
    private CommentMapper commentMapper;

    @Override
    @Transactional
    public boolean toggleClubLike(int clubNo, int userNo) {
        boolean isLiked = likeMapper.countClubLike(clubNo, userNo) > 0;
        
        if (isLiked) {
            // 좋아요 취소
            likeMapper.deleteClubLike(clubNo, userNo);
            clubMapper.decrementLikeCount(clubNo);
            return false;
        } else {
            // 좋아요 추가
            ClubLike like = new ClubLike();
            like.setClubNo(clubNo);
            like.setUserNo(userNo);
            likeMapper.insertClubLike(like);
            clubMapper.incrementLikeCount(clubNo);
            return true;
        }
    }

    @Override
    @Transactional
    public boolean toggleBoardLike(int boardNo, int userNo) {
        boolean isLiked = likeMapper.countBoardLike(boardNo, userNo) > 0;
        
        if (isLiked) {
            likeMapper.deleteBoardLike(boardNo, userNo);
            boardMapper.decrementLikeCount(boardNo);
            return false;
        } else {
            BoardLike like = new BoardLike();
            like.setBoardNo(boardNo);
            like.setUserNo(userNo);
            likeMapper.insertBoardLike(like);
            boardMapper.incrementLikeCount(boardNo);
            return true;
        }
    }

    @Override
    @Transactional
    public boolean toggleCommentLike(int commentNo, int userNo) {
        boolean isLiked = likeMapper.countCommentLike(commentNo, userNo) > 0;
        
        if (isLiked) {
            likeMapper.deleteCommentLike(commentNo, userNo);
            commentMapper.decrementLikeCount(commentNo);
            return false;
        } else {
            CommentLike like = new CommentLike();
            like.setCommentNo(commentNo);
            like.setUserNo(userNo);
            likeMapper.insertCommentLike(like);
            commentMapper.incrementLikeCount(commentNo);
            return true;
        }
    }

    @Override
    public boolean isClubLiked(int clubNo, int userNo) {
        return likeMapper.countClubLike(clubNo, userNo) > 0;
    }

    @Override
    public boolean isBoardLiked(int boardNo, int userNo) {
        return likeMapper.countBoardLike(boardNo, userNo) > 0;
    }

    @Override
    public boolean isCommentLiked(int commentNo, int userNo) {
        return likeMapper.countCommentLike(commentNo, userNo) > 0;
    }
}
