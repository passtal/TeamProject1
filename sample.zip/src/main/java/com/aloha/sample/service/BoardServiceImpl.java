package com.aloha.sample.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.aloha.sample.dao.BoardMapper;
import com.aloha.sample.dto.Board;
import com.aloha.sample.dto.BoardImage;

/**
 * 게시판 서비스 구현체
 */
@Service
public class BoardServiceImpl implements BoardService {

    @Autowired
    private BoardMapper boardMapper;

    @Override
    public List<Board> listByClub(int clubNo) {
        return boardMapper.listByClub(clubNo);
    }

    @Override
    public List<Board> listNoticeByClub(int clubNo) {
        return boardMapper.listNoticeByClub(clubNo);
    }

    @Override
    public List<Board> listByWriter(int writerNo) {
        return boardMapper.listByWriter(writerNo);
    }

    @Override
    public List<Board> searchByClub(int clubNo, String keyword) {
        return boardMapper.searchByClub(clubNo, keyword);
    }

    @Override
    public Board selectByNo(int no) {
        Board board = boardMapper.selectByNo(no);
        if (board != null) {
            // 이미지 목록 조회
            List<BoardImage> images = boardMapper.listImageByBoard(no);
            board.setImageList(images);
        }
        return board;
    }

    @Override
    @Transactional
    public int insert(Board board, List<BoardImage> images) {
        int result = boardMapper.insert(board);
        
        // 이미지 등록
        if (result > 0 && images != null && !images.isEmpty()) {
            int seq = 0;
            for (BoardImage image : images) {
                image.setBoardNo(board.getNo());
                image.setSeq(seq++);
                boardMapper.insertImage(image);
            }
        }
        
        return result;
    }

    @Override
    @Transactional
    public int update(Board board, List<BoardImage> images) {
        int result = boardMapper.update(board);
        
        // 기존 이미지 삭제 후 재등록
        if (result > 0 && images != null) {
            boardMapper.deleteImageByBoard(board.getNo());
            int seq = 0;
            for (BoardImage image : images) {
                image.setBoardNo(board.getNo());
                image.setSeq(seq++);
                boardMapper.insertImage(image);
            }
        }
        
        return result;
    }

    @Override
    @Transactional
    public int delete(int no) {
        // 이미지 먼저 삭제
        boardMapper.deleteImageByBoard(no);
        return boardMapper.delete(no);
    }

    @Override
    public int incrementViewCount(int no) {
        return boardMapper.incrementViewCount(no);
    }
    
    @Override
    public List<Board> listNotices(int clubNo) {
        return boardMapper.listNoticeByClub(clubNo);
    }
    
    @Override
    public int insert(Board board) {
        return boardMapper.insert(board);
    }
    
    @Override
    public int update(Board board) {
        return boardMapper.update(board);
    }
}
