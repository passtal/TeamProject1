package com.aloha.sample.service;

/**
 * 좋아요 서비스 인터페이스
 */
public interface LikeService {
    
    // 모임 좋아요 토글 (true: 좋아요 추가, false: 좋아요 삭제)
    boolean toggleClubLike(int clubNo, int userNo);
    
    // 게시글 좋아요 토글
    boolean toggleBoardLike(int boardNo, int userNo);
    
    // 댓글 좋아요 토글
    boolean toggleCommentLike(int commentNo, int userNo);
    
    // 모임 좋아요 여부 확인
    boolean isClubLiked(int clubNo, int userNo);
    
    // 게시글 좋아요 여부 확인
    boolean isBoardLiked(int boardNo, int userNo);
    
    // 댓글 좋아요 여부 확인
    boolean isCommentLiked(int commentNo, int userNo);
}
