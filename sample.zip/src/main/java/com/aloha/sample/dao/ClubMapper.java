package com.aloha.sample.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.aloha.sample.dto.Club;

/**
 * 모임 Mapper
 */
@Mapper
public interface ClubMapper {
    
    // 모임 목록 조회
    List<Club> list();
    
    // 카테고리별 모임 목록 조회
    List<Club> listByCategory(@Param("categoryNo") int categoryNo);
    
    // 소분류별 모임 목록 조회
    List<Club> listBySubCategory(@Param("subCategoryNo") int subCategoryNo);
    
    // 모임장별 모임 목록 조회
    List<Club> listByHost(@Param("hostNo") int hostNo);
    
    // 인기 모임 목록 (좋아요 순)
    List<Club> listPopular(@Param("limit") int limit);
    
    // 최신 모임 목록
    List<Club> listRecent(@Param("limit") int limit);
    
    // 모임 검색
    List<Club> search(@Param("keyword") String keyword);
    
    // 모임 단건 조회
    Club selectByNo(@Param("no") int no);
    
    // 모임 등록
    int insert(Club club);
    
    // 모임 수정
    int update(Club club);
    
    // 모임 삭제
    int delete(@Param("no") int no);
    
    // 조회수 증가
    int incrementViewCount(@Param("no") int no);
    
    // 좋아요 수 증가
    int incrementLikeCount(@Param("no") int no);
    
    // 좋아요 수 감소
    int decrementLikeCount(@Param("no") int no);
    
    // 현재 멤버 수 증가
    int incrementCurrentMembers(@Param("no") int no);
    
    // 현재 멤버 수 감소
    int decrementCurrentMembers(@Param("no") int no);
    
    // 모임 상태 변경
    int updateStatus(@Param("no") int no, @Param("status") String status);
    
    // 모임 수 조회
    int count();
    
    // 마감 임박 모임
    List<Club> listUpcoming(@Param("limit") int limit);
}
