package com.aloha.sample.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.aloha.sample.dto.Board;
import com.aloha.sample.dto.BoardImage;

/**
 * 게시글 Mapper
 */
@Mapper
public interface BoardMapper {
    
    // 게시글 목록 조회 (모임별)
    List<Board> listByClub(@Param("clubNo") int clubNo);
    
    // 공지 게시글 목록 조회 (모임별)
    List<Board> listNoticeByClub(@Param("clubNo") int clubNo);
    
    // 작성자별 게시글 목록 조회
    List<Board> listByWriter(@Param("writerNo") int writerNo);
    
    // 게시글 검색 (모임 내)
    List<Board> searchByClub(@Param("clubNo") int clubNo, @Param("keyword") String keyword);
    
    // 게시글 단건 조회
    Board selectByNo(@Param("no") int no);
    
    // 게시글 등록
    int insert(Board board);
    
    // 게시글 수정
    int update(Board board);
    
    // 게시글 삭제
    int delete(@Param("no") int no);
    
    // 조회수 증가
    int incrementViewCount(@Param("no") int no);
    
    // 좋아요 수 증가
    int incrementLikeCount(@Param("no") int no);
    
    // 좋아요 수 감소
    int decrementLikeCount(@Param("no") int no);
    
    // 댓글 수 증가
    int incrementCommentCount(@Param("no") int no);
    
    // 댓글 수 감소
    int decrementCommentCount(@Param("no") int no);
    
    // ===== 게시글 이미지 =====
    
    // 이미지 목록 조회
    List<BoardImage> listImageByBoard(@Param("boardNo") int boardNo);
    
    // 이미지 등록
    int insertImage(BoardImage image);
    
    // 이미지 삭제
    int deleteImage(@Param("no") int no);
    
    // 게시글 이미지 전체 삭제
    int deleteImageByBoard(@Param("boardNo") int boardNo);
}
