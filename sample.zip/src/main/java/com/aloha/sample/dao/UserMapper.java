package com.aloha.sample.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.aloha.sample.dto.User;

/**
 * 회원 Mapper
 */
@Mapper
public interface UserMapper {
    
    // 회원 목록 조회
    List<User> list();
    
    // 회원 단건 조회 (no)
    User selectByNo(@Param("no") int no);
    
    // 회원 단건 조회 (userId - 이메일)
    User selectByUserId(@Param("userId") String userId);
    
    // 회원 단건 조회 (username - 닉네임)
    User selectByUsername(@Param("username") String username);
    
    // 회원 등록
    int insert(User user);
    
    // 회원 수정
    int update(User user);
    
    // 회원 삭제
    int delete(@Param("no") int no);
    
    // 아이디 중복 확인
    int countByUserId(@Param("userId") String userId);
    
    // 닉네임 중복 확인
    int countByUsername(@Param("username") String username);
    
    // 신고 횟수 증가
    int incrementReportCount(@Param("no") int no);
    
    // 차단 처리
    int updateBanned(@Param("no") int no, @Param("isBanned") String isBanned);
    
    // 회원 수 조회
    int count();
}
