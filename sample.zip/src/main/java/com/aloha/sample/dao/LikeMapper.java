package com.aloha.sample.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.aloha.sample.dto.BoardLike;
import com.aloha.sample.dto.ClubLike;
import com.aloha.sample.dto.CommentLike;

/**
 * 좋아요 Mapper
 */
@Mapper
public interface LikeMapper {
    
    // ===== 모임 좋아요 =====
    
    // 모임 좋아요 등록
    int insertClubLike(ClubLike like);
    
    // 모임 좋아요 삭제
    int deleteClubLike(@Param("clubNo") int clubNo, @Param("userNo") int userNo);
    
    // 모임 좋아요 여부 확인
    int countClubLike(@Param("clubNo") int clubNo, @Param("userNo") int userNo);
    
    // 모임 좋아요 수 조회
    int countClubLikeByClub(@Param("clubNo") int clubNo);
    
    // 회원별 좋아요 모임 목록
    List<ClubLike> listClubLikeByUser(@Param("userNo") int userNo);
    
    // ===== 게시글 좋아요 =====
    
    // 게시글 좋아요 등록
    int insertBoardLike(BoardLike like);
    
    // 게시글 좋아요 삭제
    int deleteBoardLike(@Param("boardNo") int boardNo, @Param("userNo") int userNo);
    
    // 게시글 좋아요 여부 확인
    int countBoardLike(@Param("boardNo") int boardNo, @Param("userNo") int userNo);
    
    // 게시글 좋아요 수 조회
    int countBoardLikeByBoard(@Param("boardNo") int boardNo);
    
    // ===== 댓글 좋아요 =====
    
    // 댓글 좋아요 등록
    int insertCommentLike(CommentLike like);
    
    // 댓글 좋아요 삭제
    int deleteCommentLike(@Param("commentNo") int commentNo, @Param("userNo") int userNo);
    
    // 댓글 좋아요 여부 확인
    int countCommentLike(@Param("commentNo") int commentNo, @Param("userNo") int userNo);
    
    // 댓글 좋아요 수 조회
    int countCommentLikeByComment(@Param("commentNo") int commentNo);
}
