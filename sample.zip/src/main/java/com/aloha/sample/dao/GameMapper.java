package com.aloha.sample.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.aloha.sample.dto.Game;

/**
 * 랜덤 게임 Mapper
 */
@Mapper
public interface GameMapper {
    
    // 게임 목록 조회 (모임별)
    List<Game> listByClub(@Param("clubNo") int clubNo);
    
    // 생성자별 게임 목록 조회
    List<Game> listByCreator(@Param("createdBy") int createdBy);
    
    // 최근 게임 목록 조회 (모임별)
    List<Game> listRecentByClub(@Param("clubNo") int clubNo, @Param("limit") int limit);
    
    // 게임 단건 조회
    Game selectByNo(@Param("no") int no);
    
    // 게임 등록
    int insert(Game game);
    
    // 게임 결과 저장
    int updateResult(@Param("no") int no, @Param("result") String result);
    
    // 게임 삭제
    int delete(@Param("no") int no);
}
