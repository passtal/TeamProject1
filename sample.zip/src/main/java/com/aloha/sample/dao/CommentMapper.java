package com.aloha.sample.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.aloha.sample.dto.Comment;

/**
 * 댓글 Mapper
 */
@Mapper
public interface CommentMapper {
    
    // 댓글 목록 조회 (게시글별)
    List<Comment> listByBoard(@Param("boardNo") int boardNo);
    
    // 작성자별 댓글 목록 조회
    List<Comment> listByWriter(@Param("writerNo") int writerNo);
    
    // 댓글 단건 조회
    Comment selectByNo(@Param("no") int no);
    
    // 댓글 등록
    int insert(Comment comment);
    
    // 댓글 수정
    int update(Comment comment);
    
    // 댓글 삭제
    int delete(@Param("no") int no);
    
    // 좋아요 수 증가
    int incrementLikeCount(@Param("no") int no);
    
    // 좋아요 수 감소
    int decrementLikeCount(@Param("no") int no);
    
    // 게시글별 댓글 수 조회
    int countByBoard(@Param("boardNo") int boardNo);
}
