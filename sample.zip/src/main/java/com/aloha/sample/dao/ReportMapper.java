package com.aloha.sample.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.aloha.sample.dto.Report;
import com.aloha.sample.dto.UserBan;

/**
 * 신고/차단 Mapper
 */
@Mapper
public interface ReportMapper {
    
    // ===== 신고 =====
    
    // 신고 목록 조회 (전체)
    List<Report> list();
    
    // 모임별 신고 목록 조회
    List<Report> listByClub(@Param("clubNo") int clubNo);
    
    // 신고자별 신고 목록 조회
    List<Report> listByReporter(@Param("reporterNo") int reporterNo);
    
    // 피신고자별 신고 목록 조회
    List<Report> listByTarget(@Param("targetNo") int targetNo);
    
    // 신고 단건 조회
    Report selectByNo(@Param("no") int no);
    
    // 신고 등록
    int insert(Report report);
    
    // 신고 삭제
    int delete(@Param("no") int no);
    
    // 중복 신고 확인
    int countByClubReporterTarget(@Param("clubNo") int clubNo, 
                                   @Param("reporterNo") int reporterNo, 
                                   @Param("targetNo") int targetNo);
    
    // ===== 차단 =====
    
    // 차단 이력 목록 조회
    List<UserBan> listBan();
    
    // 회원별 차단 이력 조회
    List<UserBan> listBanByUser(@Param("userNo") int userNo);
    
    // 활성 차단 조회
    UserBan selectActiveBan(@Param("userNo") int userNo);
    
    // 차단 단건 조회
    UserBan selectBanByNo(@Param("no") int no);
    
    // 차단 등록
    int insertBan(UserBan ban);
    
    // 차단 해제
    int updateBanActive(@Param("no") int no, @Param("isActive") String isActive);
    
    // 차단 삭제
    int deleteBan(@Param("no") int no);
}
