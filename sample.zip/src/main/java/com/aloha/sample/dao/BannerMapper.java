package com.aloha.sample.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.aloha.sample.dto.Banner;

/**
 * 배너 Mapper
 */
@Mapper
public interface BannerMapper {
    
    // 배너 목록 조회
    List<Banner> list();
    
    // 활성 배너 목록 조회
    List<Banner> listActive();
    
    // 위치별 배너 목록 조회
    List<Banner> listByPosition(@Param("position") String position);
    
    // 배너 단건 조회
    Banner selectByNo(@Param("no") int no);
    
    // 배너 등록
    int insert(Banner banner);
    
    // 배너 수정
    int update(Banner banner);
    
    // 배너 삭제
    int delete(@Param("no") int no);
    
    // 클릭 수 증가
    int incrementClickCount(@Param("no") int no);
    
    // 활성화 상태 변경
    int updateActive(@Param("no") int no, @Param("isActive") String isActive);
}
