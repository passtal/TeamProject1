package com.aloha.sample.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.aloha.sample.dto.ClubMember;

/**
 * 모임 멤버 Mapper
 */
@Mapper
public interface MemberMapper {
    
    // 모임 멤버 목록 조회
    List<ClubMember> listByClub(@Param("clubNo") int clubNo);
    
    // 회원별 가입 모임 목록 조회
    List<ClubMember> listByUser(@Param("userNo") int userNo);
    
    // 승인된 멤버 목록 조회
    List<ClubMember> listApproved(@Param("clubNo") int clubNo);
    
    // 대기중 멤버 목록 조회 (가입 신청자)
    List<ClubMember> listPending(@Param("clubNo") int clubNo);
    
    // 멤버 단건 조회
    ClubMember selectByNo(@Param("no") int no);
    
    // 멤버 조회 (모임+회원)
    ClubMember selectByClubAndUser(@Param("clubNo") int clubNo, @Param("userNo") int userNo);
    
    // 멤버 등록 (가입 신청)
    int insert(ClubMember member);
    
    // 멤버 상태 변경 (승인/거절)
    int updateStatus(@Param("no") int no, @Param("status") String status);
    
    // 멤버 삭제 (탈퇴)
    int delete(@Param("no") int no);
    
    // 멤버 삭제 (모임+회원)
    int deleteByClubAndUser(@Param("clubNo") int clubNo, @Param("userNo") int userNo);
    
    // 멤버 여부 확인
    int countByClubAndUser(@Param("clubNo") int clubNo, @Param("userNo") int userNo);
}
