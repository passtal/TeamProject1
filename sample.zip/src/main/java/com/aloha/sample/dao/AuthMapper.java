package com.aloha.sample.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.aloha.sample.dto.Auth;

/**
 * 권한 Mapper
 */
@Mapper
public interface AuthMapper {
    
    // 회원 권한 목록 조회
    List<Auth> listByUserNo(@Param("userNo") int userNo);
    
    // 권한 등록
    int insert(Auth auth);
    
    // 권한 삭제 (회원번호로)
    int deleteByUserNo(@Param("userNo") int userNo);
    
    // 권한 삭제 (권한명으로)
    int delete(@Param("userNo") int userNo, @Param("auth") String auth);
}
