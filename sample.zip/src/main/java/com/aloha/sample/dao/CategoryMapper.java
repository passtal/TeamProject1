package com.aloha.sample.dao;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.aloha.sample.dto.Category;
import com.aloha.sample.dto.SubCategory;

/**
 * 카테고리 Mapper
 */
@Mapper
public interface CategoryMapper {
    
    // 대분류 카테고리 목록 조회
    List<Category> list();
    
    // 대분류 카테고리 단건 조회
    Category selectByNo(@Param("no") int no);
    
    // 대분류 카테고리 등록
    int insert(Category category);
    
    // 대분류 카테고리 수정
    int update(Category category);
    
    // 대분류 카테고리 삭제
    int delete(@Param("no") int no);
    
    // 소분류 카테고리 목록 조회 (대분류별)
    List<SubCategory> listSubByCategory(@Param("categoryNo") int categoryNo);
    
    // 소분류 카테고리 단건 조회
    SubCategory selectSubByNo(@Param("no") int no);
    
    // 소분류 카테고리 등록
    int insertSub(SubCategory subCategory);
    
    // 소분류 카테고리 수정
    int updateSub(SubCategory subCategory);
    
    // 소분류 카테고리 삭제
    int deleteSub(@Param("no") int no);
}
