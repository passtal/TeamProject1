/**
 * 두루두루 - 공통 JavaScript 유틸리티
 */

// CSRF 토큰 설정 (Spring Security)
const csrfToken = $('meta[name="_csrf"]').attr('content');
const csrfHeader = $('meta[name="_csrf_header"]').attr('content');

// AJAX 요청 시 CSRF 토큰 자동 추가
$.ajaxSetup({
    beforeSend: function(xhr) {
        if (csrfToken && csrfHeader) {
            xhr.setRequestHeader(csrfHeader, csrfToken);
        }
    }
});

// ==============================================
// 유틸리티 함수
// ==============================================

/**
 * 날짜 포맷팅
 * @param {Date|string} date 날짜
 * @param {string} format 포맷 (기본: 'YYYY-MM-DD')
 * @returns {string} 포맷된 날짜 문자열
 */
function formatDate(date, format = 'YYYY-MM-DD') {
    const d = new Date(date);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    const hours = String(d.getHours()).padStart(2, '0');
    const minutes = String(d.getMinutes()).padStart(2, '0');
    const seconds = String(d.getSeconds()).padStart(2, '0');
    
    return format
        .replace('YYYY', year)
        .replace('MM', month)
        .replace('DD', day)
        .replace('HH', hours)
        .replace('mm', minutes)
        .replace('ss', seconds);
}

/**
 * 상대적 시간 표시 (예: "5분 전", "3일 전")
 * @param {Date|string} date 날짜
 * @returns {string} 상대적 시간 문자열
 */
function timeAgo(date) {
    const now = new Date();
    const diff = now - new Date(date);
    const seconds = Math.floor(diff / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    const months = Math.floor(days / 30);
    const years = Math.floor(months / 12);
    
    if (years > 0) return `${years}년 전`;
    if (months > 0) return `${months}개월 전`;
    if (days > 0) return `${days}일 전`;
    if (hours > 0) return `${hours}시간 전`;
    if (minutes > 0) return `${minutes}분 전`;
    return '방금 전';
}

/**
 * 숫자 포맷팅 (천 단위 콤마)
 * @param {number} num 숫자
 * @returns {string} 포맷된 숫자 문자열
 */
function formatNumber(num) {
    return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

/**
 * HTML 이스케이프
 * @param {string} str 문자열
 * @returns {string} 이스케이프된 문자열
 */
function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML;
}

// ==============================================
// Alert & Confirm
// ==============================================

/**
 * Bootstrap Alert 표시
 * @param {string} message 메시지
 * @param {string} type 타입 (success, danger, warning, info)
 * @param {number} duration 표시 시간 (ms)
 */
function showAlert(message, type = 'info', duration = 3000) {
    const alertId = 'alert-' + Date.now();
    const alertHtml = `
        <div id="${alertId}" class="alert alert-${type} alert-dismissible fade show position-fixed" 
             style="top: 80px; right: 20px; z-index: 9999; min-width: 300px;">
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    `;
    $('body').append(alertHtml);
    
    setTimeout(() => {
        $(`#${alertId}`).fadeOut(300, function() {
            $(this).remove();
        });
    }, duration);
}

/**
 * 확인 다이얼로그
 * @param {string} message 메시지
 * @param {function} callback 확인 시 콜백
 * @param {string} title 제목
 */
function showConfirm(message, callback, title = '확인') {
    const modalId = 'confirm-modal-' + Date.now();
    const modalHtml = `
        <div class="modal fade" id="${modalId}" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">${title}</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <p>${message}</p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">취소</button>
                        <button type="button" class="btn btn-primary confirm-btn">확인</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    $('body').append(modalHtml);
    
    const modal = new bootstrap.Modal(document.getElementById(modalId));
    
    $(`#${modalId} .confirm-btn`).on('click', function() {
        modal.hide();
        if (typeof callback === 'function') {
            callback();
        }
    });
    
    $(`#${modalId}`).on('hidden.bs.modal', function() {
        $(this).remove();
    });
    
    modal.show();
}

// ==============================================
// 좋아요 기능
// ==============================================

/**
 * 좋아요 토글
 * @param {string} type 타입 (club, board, comment)
 * @param {number} targetNo 대상 번호
 * @param {HTMLElement} btn 버튼 요소
 */
function toggleLike(type, targetNo, btn) {
    $.ajax({
        url: `/like/${type}/${targetNo}`,
        type: 'POST',
        dataType: 'json',
        success: function(response) {
            if (response.success) {
                const $btn = $(btn);
                const $icon = $btn.find('i');
                const $count = $btn.find('.like-count');
                
                if (response.liked) {
                    $icon.removeClass('bi-heart').addClass('bi-heart-fill text-danger');
                    $btn.addClass('active');
                } else {
                    $icon.removeClass('bi-heart-fill text-danger').addClass('bi-heart');
                    $btn.removeClass('active');
                }
                
                if ($count.length) {
                    $count.text(response.likeCount);
                }
                
                // 애니메이션 효과
                $icon.addClass('pulse');
                setTimeout(() => $icon.removeClass('pulse'), 300);
            }
        },
        error: function(xhr) {
            if (xhr.status === 401) {
                showAlert('로그인이 필요합니다.', 'warning');
            } else {
                showAlert('오류가 발생했습니다.', 'danger');
            }
        }
    });
}

// ==============================================
// 댓글 기능
// ==============================================

const Comment = {
    /**
     * 댓글 작성
     * @param {number} boardNo 게시글 번호
     * @param {string} content 내용
     * @param {number|null} parentNo 부모 댓글 번호
     * @param {function} callback 성공 콜백
     */
    write: function(boardNo, content, parentNo = null, callback) {
        $.ajax({
            url: '/comment',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                boardNo: boardNo,
                content: content,
                parentNo: parentNo
            }),
            success: function(response) {
                if (response.success) {
                    showAlert('댓글이 작성되었습니다.', 'success');
                    if (typeof callback === 'function') callback(response);
                }
            },
            error: function(xhr) {
                if (xhr.status === 401) {
                    showAlert('로그인이 필요합니다.', 'warning');
                } else {
                    showAlert('댓글 작성에 실패했습니다.', 'danger');
                }
            }
        });
    },
    
    /**
     * 댓글 삭제
     * @param {number} commentNo 댓글 번호
     * @param {function} callback 성공 콜백
     */
    delete: function(commentNo, callback) {
        showConfirm('댓글을 삭제하시겠습니까?', function() {
            $.ajax({
                url: `/comment/${commentNo}`,
                type: 'DELETE',
                success: function(response) {
                    if (response.success) {
                        showAlert('댓글이 삭제되었습니다.', 'success');
                        if (typeof callback === 'function') callback(response);
                    }
                },
                error: function() {
                    showAlert('댓글 삭제에 실패했습니다.', 'danger');
                }
            });
        });
    }
};

// ==============================================
// 신고 기능
// ==============================================

const Report = {
    /**
     * 신고하기
     * @param {number} clubNo 모임 번호
     * @param {number} reportedUserNo 피신고자 번호
     * @param {string} reason 신고 사유
     * @param {function} callback 성공 콜백
     */
    submit: function(clubNo, reportedUserNo, reason, callback) {
        $.ajax({
            url: '/report',
            type: 'POST',
            contentType: 'application/json',
            data: JSON.stringify({
                clubNo: clubNo,
                reportedUserNo: reportedUserNo,
                reason: reason
            }),
            success: function(response) {
                if (response.success) {
                    showAlert('신고가 접수되었습니다.', 'success');
                    if (typeof callback === 'function') callback(response);
                }
            },
            error: function(xhr) {
                if (xhr.status === 401) {
                    showAlert('로그인이 필요합니다.', 'warning');
                } else {
                    showAlert('신고 접수에 실패했습니다.', 'danger');
                }
            }
        });
    }
};

// ==============================================
// 파일 업로드
// ==============================================

/**
 * 이미지 미리보기
 * @param {HTMLInputElement} input 파일 입력 요소
 * @param {string} previewContainerId 미리보기 컨테이너 ID
 */
function previewImages(input, previewContainerId) {
    const $container = $(`#${previewContainerId}`);
    $container.empty();
    
    if (input.files) {
        Array.from(input.files).forEach((file, index) => {
            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    const html = `
                        <div class="preview-item d-inline-block position-relative me-2 mb-2">
                            <img src="${e.target.result}" class="img-thumbnail" style="width: 100px; height: 100px; object-fit: cover;">
                            <button type="button" class="btn btn-danger btn-sm position-absolute top-0 end-0" 
                                    style="transform: translate(50%, -50%);" onclick="removePreview(this, ${index})">
                                <i class="bi bi-x"></i>
                            </button>
                        </div>
                    `;
                    $container.append(html);
                };
                reader.readAsDataURL(file);
            }
        });
    }
}

// ==============================================
// 폼 유효성 검사
// ==============================================

const Validate = {
    /**
     * 이메일 유효성 검사
     * @param {string} email 이메일
     * @returns {boolean}
     */
    email: function(email) {
        const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    },
    
    /**
     * 아이디 유효성 검사 (영문, 숫자 4-20자)
     * @param {string} id 아이디
     * @returns {boolean}
     */
    userId: function(id) {
        const regex = /^[a-zA-Z0-9]{4,20}$/;
        return regex.test(id);
    },
    
    /**
     * 비밀번호 유효성 검사 (8자 이상)
     * @param {string} password 비밀번호
     * @returns {boolean}
     */
    password: function(password) {
        return password.length >= 8;
    },
    
    /**
     * 필수 입력 검사
     * @param {string} value 값
     * @returns {boolean}
     */
    required: function(value) {
        return value && value.trim().length > 0;
    }
};

// ==============================================
// 아이디/닉네임 중복 체크
// ==============================================

/**
 * 아이디 중복 체크
 * @param {string} userId 아이디
 * @param {function} callback 콜백 (available: boolean)
 */
function checkUserIdDuplicate(userId, callback) {
    $.ajax({
        url: '/user/check-id',
        type: 'GET',
        data: { userId: userId },
        success: function(response) {
            callback(response.available);
        },
        error: function() {
            callback(false);
        }
    });
}

/**
 * 닉네임 중복 체크
 * @param {string} nickname 닉네임
 * @param {function} callback 콜백 (available: boolean)
 */
function checkNicknameDuplicate(nickname, callback) {
    $.ajax({
        url: '/user/check-nickname',
        type: 'GET',
        data: { nickname: nickname },
        success: function(response) {
            callback(response.available);
        },
        error: function() {
            callback(false);
        }
    });
}

// ==============================================
// 초기화
// ==============================================

$(document).ready(function() {
    // 툴팁 초기화
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // 자동 숨김 알림
    setTimeout(function() {
        $('.alert-dismissible.auto-hide').fadeOut(500);
    }, 3000);
    
    console.log('두루두루 - 공통 스크립트 로드 완료');
});
