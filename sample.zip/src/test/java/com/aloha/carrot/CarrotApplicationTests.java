package com.aloha.carrot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarrotApplicationTests {

	@Test
	void contextLoads() {
	}

}
